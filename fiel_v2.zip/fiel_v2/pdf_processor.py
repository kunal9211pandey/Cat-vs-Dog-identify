"""
PDF Processor
=============
Extracts high-resolution images from PDF pages and parses all text
blocks with their exact bounding-box coordinates.

Why read text directly from the PDF?
  -> pymupdf gives us pixel-accurate text positions without OCR errors.
    We still run a vision model on top to catch:
    a) areas that are drawn but have no text label
    b) multi-line / fragmented labels

BUG-FIX (Legend exclusion)
---------------------------
Architectural sheet layout (RSP / standard A0/A1):
  ┌──────────────────────────┬────────────┐
  │                          │  RISER     │
  │   DRAWING AREA           │  SCHEDULE  │
  │   (floor plan)           │  LEGEND    │
  │                          │  KEY PLAN  │
  ├──────────────────────────┴────────────┤
  │        TITLE BLOCK / GENERAL NOTES   │
  └───────────────────────────────────────┘

Any text block whose left edge (x0) starts at or beyond LEGEND_X_FRAC
of the page width is part of the right-side schedule column and MUST be
excluded.  Likewise, blocks whose top edge (y0) starts at or beyond
TITLE_Y_FRAC are in the notes/title strip.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import fitz                     # pymupdf
import numpy as np
from PIL import Image

from config import (
    PDF_DPI, OUTPUT_DIR, KNOWN_AREAS,
    LEGEND_X_FRAC, TITLE_Y_FRAC,
)

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
#  Compile-once regex patterns
# ──────────────────────────────────────────────────────────────────────────────

# Standalone riser codes: R1, R14, R9A, RB18, RT31 ...
_RE_RISER_CODE = re.compile(r'^R[BT]?[0-9]{1,2}[A-Za-z]?$')

# Riser-schedule body rows:  "R1  Small power, AHU loads & UPS Riser"
#                            "R14 FHC riser"
_RE_RISER_ROW = re.compile(
    r'^\s*R[BT]?[0-9]{1,2}[A-Za-z]?\s+.{3,}',   # starts with riser code + text
    re.IGNORECASE,
)

# Dimension / level strings
_RE_DIMENSION = re.compile(
    # Level / direction tags
    r'^(FFL|DIL|UP|DN|UP\s*DN|N|©)[\s\+\-\d\.°M]*$'
    # Pure number optionally with unit (but NOT 4-digit numbers < 2000 = could be a room no.)
    r'|^(?:1[5-9]\d{2}|[2-9]\d{3}|\d{5,})(?:\s*(?:MM|M|SQ\.M|SQM))?$'
    # Grid dimension numbers (>= 5000) -- common CAD grid: 9200, 11000
    r'|^\d+\.\d+$',     # decimal-only: 639.200, 566.550 etc (level values)
    re.IGNORECASE,
)

# Legend header / annotation-region keywords to drop
_LEGEND_KEYWORDS = {
    "RISER SCHEDULE", "RISER SCHEDULES", "LEGEND",
    "GENERAL NOTES", "GENERAL NOTE",
    "KEY PLAN", "NOTES",
    "STR RC WALL", "NON STR RC WALL", "BLOCK WALL",
    "GOOD FOR CONSTRUCTION", "FOR CONSTRUCTION",
    "PROJECT TITLE", "PROJECT CONSULTANTS", "DRAWING TITLE",
    "DRAWING NO", "FILE NAME", "JOB NO", "JOB.NO",
    "PROJECT LEAD", "PROJECT CO-ORDINATOR",
    "CHECKED", "DRAWN", "SCALE",
    "NORTH", "KEY PLAN",
    "ALL DIMENSIONS ARE IN MILLIMETERS",
    "THIS DRAWING IS A COPYRIGHT",
    "ALL DIMENSIONS SHALL BE VERIFIED",
    "THIS DRAWING IS TO BE READ AND NOT SCALED",
    "COPYRIGHT", "© COPYRIGHT",
    "PROPOSED OFFICE PROJECT",
    "GOOGLE CONNECT SERVICES",
    "SURVEY NO",
    "ISSUED FOR CONSTRUCTION",
    "REVISED DRAWING",
    "VALUE ENGINEERING",
    "RSP DESIGN CONSULTANTS",
    "RSP HOUSE",
    "SIGN :", "DATE :",
    "NO. ISSUE DATE",
    "FLOOR PLAN - OVERALL",
    "BASEMENT",   # catches "BASEMENT 01 FLOOR PLAN - OVERALL" in title
}

# Words that strongly suggest a block is a riser schedule description.
# IMPORTANT: keep these SPECIFIC -- do NOT include bare "SHAFT" because
# "HVAC SHAFT", "PHE SHAFT", "EXHAUST SHAFT" are valid area names that
# appear inside the drawing area.  Only filter riser-schedule descriptions
# that combine a riser type with a suffix like "RISER" or "FLUE".
_RISER_DESC_WORDS = {
    "VENTILATION RISER", "CABLE RISER", "PRESSURIZATION RISER",
    "FLUE RISER", "GENERATOR FLUE",
    "EMERGENCY LIGHTING RISER", "SMALL POWER RISER",
    "CHILLED WATER RISER",
    "KITCHEN EXTRACT VENTILATION",
    "STP EXHAUST RISER",
    "TERRACE RAIN WATER",
    "DRAINAGE PIPES",
    "CHW PIPES",
    "DOES NOT EXIST", "DOES NOT EXIT",
    "HT CABLE RISER",
    "FUTURE M & E RISER", "FUTURE CABLE RISER",
    "BASE-BUILD",          # "Base-Build HV services Riser"
    "AHU LOADS & UPS RISER",
}


# ──────────────────────────────────────────────────────────────────────────────
#  Filter helpers
# ──────────────────────────────────────────────────────────────────────────────

def _is_excluded_block(text: str) -> bool:
    """
    Return True if this text block should be EXCLUDED from area detection.
    Covers: riser codes, dimensions, legend/schedule text, title-block text.
    """
    t = text.strip()
    if not t or len(t) < 2:
        return True

    t_up = t.upper()

    # 1. Standalone riser code  (R1, R14, R9B ...)
    if _RE_RISER_CODE.match(t.strip()):
        return True

    # 2. Full riser-schedule body row
    if _RE_RISER_ROW.match(t):
        return True

    # 3. Pure dimension / level string
    for line in t.split('\n'):
        if _RE_DIMENSION.match(line.strip()):
            pass   # check if ALL lines are dimensions
    if all(_RE_DIMENSION.match(l.strip()) for l in t.split('\n') if l.strip()):
        return True

    # 4. Legend header / annotation-region keyword
    if any(kw in t_up for kw in _LEGEND_KEYWORDS):
        return True

    # 5. Riser schedule description word (in body)
    if any(word in t_up for word in _RISER_DESC_WORDS):
        return True

    # 6. Short all-uppercase single words that are likely layer names / codes
    #    e.g. "N" (north arrow label), "R1" covered above, "FM", "ABCDEGHJLK" ...
    if len(t) <= 3 and t.isupper():
        return True

    return False


def _clean_block_text(raw: str) -> str | None:
    """
    Given a raw multi-line text block, strip individual lines that are
    riser codes or dimension strings, then return the cleaned text.
    Returns None if nothing meaningful remains.
    """
    lines = [l.strip() for l in raw.replace("\r", "\n").split("\n") if l.strip()]
    kept  = []
    for line in lines:
        # Skip bare riser codes / dimensions on their own line
        if _RE_RISER_CODE.match(line):
            continue
        # Skip standalone dimension values
        if _RE_DIMENSION.match(line):
            continue
        # Skip short tokens that look like riser code sequences: "R1 R14 R9B"
        tokens = line.split()
        if tokens and all(_RE_RISER_CODE.match(t) for t in tokens):
            continue
        kept.append(line)

    if not kept:
        return None
    cleaned = " ".join(dict.fromkeys(kept))   # deduplicate while preserving order
    return cleaned if len(cleaned) >= 2 else None


def _area_category(text: str) -> str:
    """Fuzzy-match a label to the closest known area category."""
    from config import KNOWN_AREAS
    text_up = text.upper()
    best, best_score = "Unknown", 0
    for cat in KNOWN_AREAS:
        words = [w for w in cat.upper().split() if len(w) > 2]
        hits  = sum(1 for w in words if w in text_up)
        if hits > best_score:
            best, best_score = cat, hits
    return best if best_score > 0 else text


# ──────────────────────────────────────────────────────────────────────────────
#  Core processor
# ──────────────────────────────────────────────────────────────────────────────

class PDFProcessor:
    """
    Converts a single PDF page into:
      - a PIL image (for visual agents)
      - a list of area records parsed from embedded text

    Legend-region filter
    --------------------
    Text blocks whose x0 ≥ page_width * LEGEND_X_FRAC  are in the riser
    schedule / legend column and are silently dropped.
    Text blocks whose y0 ≥ page_height * TITLE_Y_FRAC   are in the title
    block / general-notes strip and are dropped.

    Usage
    -----
    proc = PDFProcessor("path/to/file.pdf")
    result = proc.process()
    image  = result["image"]          # PIL.Image
    areas  = result["text_areas"]     # list[dict]
    """

    def __init__(self, pdf_path: str | Path, dpi: int = PDF_DPI):
        self.pdf_path = Path(pdf_path)
        self.dpi      = dpi
        self.name     = self.pdf_path.stem

    # ── public ────────────────────────────────────────────────────────────────

    def process(self, page_num: int = 0) -> dict[str, Any]:
        doc  = fitz.open(str(self.pdf_path))
        page = doc[page_num]

        image      = self._render_image(page)
        text_areas = self._extract_text_areas(page, image.size)
        page_size  = (page.rect.width, page.rect.height)

        doc.close()
        logger.info(
            "Processed %s -> %dx%d px, %d text areas",
            self.pdf_path.name, image.size[0], image.size[1], len(text_areas),
        )
        return {
            "pdf_name":       self.name,
            "pdf_path":       str(self.pdf_path),
            "image":          image,
            "image_size":     image.size,
            "text_areas":     text_areas,
            "page_size_pts":  page_size,
        }

    # ── private ───────────────────────────────────────────────────────────────

    def _render_image(self, page: fitz.Page) -> Image.Image:
        mat = fitz.Matrix(self.dpi / 72, self.dpi / 72)
        pix = page.get_pixmap(matrix=mat, colorspace=fitz.csRGB, alpha=False)
        return Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

    def _extract_text_areas(
        self, page: fitz.Page, image_size: tuple[int, int]
    ) -> list[dict]:
        """
        Returns a list of area dicts with normalised [0,1] coordinates.

        Exclusions (in order):
          1. Block x0 ≥ LEGEND_X_FRAC  -> riser-schedule / legend column
          2. Block y0 ≥ TITLE_Y_FRAC   -> title block / general notes
          3. Text matches _is_excluded_block()
        """
        W_pts, H_pts = page.rect.width, page.rect.height
        W_px,  H_px  = image_size

        # Legend boundary in PDF points
        legend_x_pts = W_pts * LEGEND_X_FRAC
        title_y_pts  = H_pts * TITLE_Y_FRAC

        raw_blocks = page.get_text("blocks")  # (x0,y0,x1,y1,text,block_no,type)

        areas:          list[dict] = []
        dropped_legend: int        = 0
        dropped_filter: int        = 0

        for blk in raw_blocks:
            x0_pts, y0_pts = blk[0], blk[1]

            # ── Region filter (Bug fix #1) ─────────────────────────────────────
            if x0_pts >= legend_x_pts:
                dropped_legend += 1
                continue
            if y0_pts >= title_y_pts:
                dropped_legend += 1
                continue

            # ── Per-line cleaning + content filter ────────────────────────────
            raw_text = blk[4]
            text = _clean_block_text(raw_text)
            if text is None:
                dropped_filter += 1
                continue
            if _is_excluded_block(text):
                dropped_filter += 1
                continue

            # ── Build area record ─────────────────────────────────────────────
            x1_px = int(blk[0] / W_pts * W_px)
            y1_px = int(blk[1] / H_pts * H_px)
            x2_px = int(blk[2] / W_pts * W_px)
            y2_px = int(blk[3] / H_pts * H_px)

            x1n = round(blk[0] / W_pts, 4)
            y1n = round(blk[1] / H_pts, 4)
            x2n = round(blk[2] / W_pts, 4)
            y2n = round(blk[3] / H_pts, 4)

            category = _area_category(text)

            areas.append({
                "name":             text,
                "category":         category,
                "coordinates_px":   [x1_px, y1_px, x2_px, y2_px],
                "coordinates_norm": [x1n, y1n, x2n, y2n],
                "center_px":        [int((x1_px + x2_px) / 2), int((y1_px + y2_px) / 2)],
                "has_label":        True,
                "source":           "pdf_text",
                "confidence":       1.0,
            })

        logger.info(
            "Text extraction: %d kept | %d legend-region dropped | %d content-filtered",
            len(areas), dropped_legend, dropped_filter,
        )

        # Merge fragmented multi-line labels
        areas = self._merge_nearby_labels(areas, W_px, H_px)
        return areas

    def _merge_nearby_labels(
        self,
        areas: list[dict],
        W_px: int,
        H_px: int,
        proximity_frac: float = 0.015,   # 1.5 % of image width
    ) -> list[dict]:
        """
        Labels like 'PASS. LIFT(HR)' often arrive as two separate blocks.
        Merge blocks whose centres are within proximity_frac of each other.
        Only merge when both blocks are inside the same vertical strip (same column).
        """
        threshold = W_px * proximity_frac
        merged    = []
        used      = [False] * len(areas)

        for i, a in enumerate(areas):
            if used[i]:
                continue
            cx_a, cy_a = a["center_px"]
            group = [a]
            used[i] = True

            for j, b in enumerate(areas):
                if used[j] or i == j:
                    continue
                cx_b, cy_b = b["center_px"]
                dist = ((cx_a - cx_b) ** 2 + (cy_a - cy_b) ** 2) ** 0.5
                if dist < threshold:
                    group.append(b)
                    used[j] = True

            if len(group) == 1:
                merged.append(a)
                continue

            # Combine
            name_combined = " ".join(dict.fromkeys(g["name"] for g in group))
            all_px = [g["coordinates_px"] for g in group]
            x1_px  = min(p[0] for p in all_px)
            y1_px  = min(p[1] for p in all_px)
            x2_px  = max(p[2] for p in all_px)
            y2_px  = max(p[3] for p in all_px)
            merged.append({
                "name":             name_combined,
                "category":         _area_category(name_combined),
                "coordinates_px":   [x1_px, y1_px, x2_px, y2_px],
                "coordinates_norm": [
                    round(x1_px / W_px, 4), round(y1_px / H_px, 4),
                    round(x2_px / W_px, 4), round(y2_px / H_px, 4),
                ],
                "center_px":  [int((x1_px + x2_px) / 2), int((y1_px + y2_px) / 2)],
                "has_label":  True,
                "source":     "pdf_text_merged",
                "confidence": 1.0,
            })

        return merged


# ──────────────────────────────────────────────────────────────────────────────
#  Folder-level batch extractor
# ──────────────────────────────────────────────────────────────────────────────

def extract_all_pdfs(pdf_folder: str | Path, dpi: int = PDF_DPI) -> list[dict]:
    """Process every PDF in a folder and return a list of result dicts."""
    folder  = Path(pdf_folder)
    results = []
    pdfs    = sorted(folder.glob("*.pdf"))
    logger.info("Found %d PDF(s) in %s", len(pdfs), folder)

    for pdf_path in pdfs:
        try:
            proc   = PDFProcessor(pdf_path, dpi=dpi)
            result = proc.process()
            results.append(result)
        except Exception as exc:
            logger.error("Failed to process %s: %s", pdf_path.name, exc)

    return results
