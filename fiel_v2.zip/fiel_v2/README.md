# CAD Floor Plan AI Pipeline

Automatically analyses architectural floor plan PDFs (CAD drawings) to:
- Detect and label every area/room
- Estimate real-world area (sq m) at 1:200 drawing scale
- Calculate lighting fixtures (IS 3646 standard)
- Estimate occupancy capacity
- Output annotated images + structured JSON

Built for the **Google HQ, Gachibowli, Hyderabad** office project (RSP Design Consultants).

---

## Project Structure

```
fiel/
├── agents/                    ← All AI agents (sub-package)
│   ├── __init__.py
│   ├── base_agent.py          ← Groq API wrapper (shared by all agents)
│   ├── vision_agent.py        ← Multimodal vision: detects unlabelled areas
│   ├── ocr_agent.py           ← OCR verification of text labels
│   ├── inference_agent.py     ← Infers labels for unlabelled regions via LLM
│   ├── spatial_agent.py       ← NMS + gap detection + area size estimation
│   ├── planning_agent.py      ← Occupancy capacity estimation
│   ├── electrical_agent.py    ← Lighting fixture recommendation (IS 3646)
│   └── validation_agent.py    ← Sanity checks on final areas
│
├── data/
│   ├── pdfs/                  ← ✅ PUT YOUR PDF FILES HERE
│   ├── output/                ← Generated outputs (images + JSON)
│   ├── samples/               ← Optional sample images for testing
│   └── embeddings/            ← RAG cache (auto-generated)
│
├── config.py                  ← All constants and settings
├── main.py                    ← CLI entry point
├── orchestrator.py            ← Coordinates all agents per floor
├── pdf_processor.py           ← PDF → image + text extraction
├── preprocessor.py            ← Image enhancement + tiling + deskew
├── output_generator.py        ← Annotated PNG + JSON output
├── rag_system.py              ← Vector store for area label lookup
└── requirements.txt
```

---

## Setup

### 1. Clone / extract

```bash
cd fiel/
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv .venv
source .venv/bin/activate       # Linux / macOS
# or
.venv\Scripts\activate          # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set your Groq API key

Create a `.env` file in the `fiel/` directory:

```dotenv
GROQ_API_KEY=gsk_your_key_here
```

Or export it as an environment variable:

```bash
export GROQ_API_KEY=gsk_your_key_here
```

Get a free key at: https://console.groq.com

### 5. Add your PDFs

Copy your floor plan PDFs into `data/pdfs/`:

```
fiel/data/pdfs/
├── B1.pdf     ← Basement 01
├── B2.pdf     ← Basement 02
├── B3.pdf     ← Basement 03
├── L17.pdf    ← 17th Floor
└── L23.pdf    ← 23rd Floor
```

The pipeline auto-detects the floor name from the filename using a built-in
mapping (B1 → Basement 01, L17 → 17th Floor, etc.).

---

## Running the Pipeline

### Process a single PDF

```bash
python main.py --input data/pdfs/L17.pdf
```

### Process all PDFs in the folder

```bash
python main.py --input data/pdfs/
```

### Fast mode (text-only, no Groq API calls)

Skips the VisionAgent. Uses only embedded PDF text for area labels.
Runs in seconds instead of minutes.

```bash
python main.py --input data/pdfs/ --no-vision
```

### Custom output directory

```bash
python main.py --input data/pdfs/ --output-dir /path/to/my/outputs
```

### Limit vision tiles per floor (cost control)

```bash
python main.py --input data/pdfs/ --max-tiles 4
```

---

## Output Files

For each processed PDF, two files are written to `data/output/`:

| File | Description |
|------|-------------|
| `17th_Floor_annotated.jpg` | Colour-coded floor plan with area labels |
| `17th_Floor_areas.json` | Full structured data for all areas |

### JSON Schema

```json
{
  "floor": "17th Floor",
  "pdf_source": "data/pdfs/L17.pdf",
  "image_size_px": [3508, 2480],
  "total_areas": 87,
  "total_sqm": 4212.5,
  "total_capacity": 420,
  "areas": [
    {
      "name": "OFFICE SPACE",
      "category": "Office Space",
      "coordinates": [120, 95, 890, 680],
      "coordinates_norm": [0.034, 0.038, 0.254, 0.274],
      "area_size_sqm": 1234.5,
      "confidence": 1.0,
      "has_label": true,
      "source": "pdf_text",
      "capacity": {
        "persons": 164,
        "density": "7.5 sqm/person",
        "notes": ""
      },
      "lighting": {
        "target_lux": 500,
        "recommended_fixtures": 124,
        "fixture_type": "40W LED panel (3500 lm)",
        "positions": [[200, 180], [400, 180], ...],
        "emergency_lights": 12,
        "notes": ""
      }
    }
  ]
}
```

---

## Pipeline Architecture

```
PDF
 │
 ├─ PDFProcessor
 │    ├─ Render page at 150 DPI → PIL image
 │    └─ Extract embedded text blocks with bounding boxes
 │         └─ BUG-FIX: exclude right 18% (legend) + bottom 9% (title block)
 │
 ├─ Preprocessor
 │    ├─ Enhance: denoise → CLAHE → unsharp mask
 │    ├─ Orientation fix: detect portrait flip + fine deskew (Hough)
 │    └─ Multi-scale tiles: coarse (1024px, 20% overlap) + fine (512px, 25%)
 │
 ├─ VisionAgent  [optional, uses Groq Llama-4 Scout vision]
 │    └─ Analyses coarse tiles → detects unlabelled areas
 │
 ├─ InferenceAgent  [for unlabelled detections]
 │    └─ RAG lookup + LLM decision → assigns probable label
 │
 ├─ SpatialAgent
 │    ├─ NMS deduplication (IoU threshold 0.5)
 │    ├─ Real-world area estimation (1:200 scale)
 │    └─ Gap detection → "Unidentified Area" placeholders
 │         └─ BUG-FIX: tighter min_size=2.5%, cap at 15%, exclude legend zone
 │
 ├─ PlanningAgent  → capacity estimation
 ├─ ElectricalAgent → lighting fixtures (IS 3646)
 ├─ ValidationAgent → sanity checks
 │
 └─ OutputGenerator → annotated JPG + JSON
```

---

## Bug Fixes in This Version

### Bug 1: Riser Schedule Parsed as "Area"

**Problem:** The Riser Schedule legend (right ~18% of sheet) was being extracted
as area text blocks, producing spurious areas like "R1 Small power, AHU loads & UPS Riser".

**Fix (pdf_processor.py):**
- Added `LEGEND_X_FRAC = 0.82` in `config.py`
- In `_extract_text_areas()`, any text block whose left edge `x0 ≥ LEGEND_X_FRAC × page_width` is silently dropped
- Same exclusion for `y0 ≥ TITLE_Y_FRAC × page_height` (title block / general notes strip)
- Added a comprehensive keyword blocklist (`_LEGEND_KEYWORDS`, `_RISER_DESC_WORDS`) as a secondary content-based filter

### Bug 2: Unidentified Area Gets Full-Page Bbox

**Problem:** The gap-detector BFS in SpatialAgent created huge `Unidentified Area`
blobs spanning the legend whitespace and page margins.

**Root causes:**
1. `min_size_frac = 0.005` was too low (caught tiny margin slivers that BFS merged into large blobs)
2. Legend/title zones were not pre-marked as "covered"
3. No upper bound on blob size

**Fix (agents/spatial_agent.py):**
- `min_size_frac` raised to `MIN_UNCOVERED_FRAC = 0.025` (2.5%)
- Legend column and title strip pre-marked as covered in the coverage mask
- Hard cap: blobs > `MAX_UNCOVERED_FRAC = 0.15` (15%) are discarded as noise
- BBox is inset by half a grid step to avoid border-hugging artefacts

---

## Configuration

Key settings in `config.py`:

| Constant | Default | Purpose |
|----------|---------|---------|
| `PDF_DPI` | 150 | Render resolution (300 for print quality) |
| `LEGEND_X_FRAC` | 0.82 | x-threshold to exclude right legend column |
| `TITLE_Y_FRAC` | 0.91 | y-threshold to exclude bottom title strip |
| `MIN_UNCOVERED_FRAC` | 0.025 | Min gap size to flag as Unidentified Area |
| `GROQ_VISION_MODEL` | `llama-4-scout-17b-16e-instruct` | Vision model |
| `GROQ_TEXT_MODEL` | `llama-3.3-70b-versatile` | Text/reasoning model |

---

## Filename → Floor Name Mapping

The orchestrator auto-detects floor name from PDF filename:

| Filename contains | Floor name |
|-------------------|------------|
| `B1` | Basement 01 |
| `B2` | Basement 02 |
| `B3` | Basement 03 |
| `GF` | Ground Floor |
| `LG` | Lower Ground |
| `L17` | 17th Floor |
| `L23` | 23rd Floor |
| `TF` | Terrace Floor |

Any unrecognised filename is converted to title case (e.g. `roof_plan.pdf` → `Roof Plan`).

---

## Troubleshooting

**"No module named 'fitz'"**
```bash
pip install pymupdf
```

**"No module named 'groq'"**
```bash
pip install groq
```

**API rate-limit errors**
Use `--no-vision` for fast text-only mode, or reduce `--max-tiles`.

**Output images look blank / no areas detected**
Check `pipeline.log` for errors. Common causes:
- PDF is scanned/rasterised (no embedded text) → enable vision mode
- GROQ_API_KEY not set

**Legend areas still appearing**
Check if your drawing has a non-standard layout where the legend is NOT in the
right 18%. Adjust `LEGEND_X_FRAC` in `config.py` to match your sheet format.
