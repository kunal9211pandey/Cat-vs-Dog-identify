"""
RAG System (TF-IDF backend)
============================
FIXED:
  1. _known_floors  -- tracks which PDFs have been learned, so no re-fitting
  2. auto-save      -- saves to disk after every new floor is added
  3. load()         -- also restores _known_floors from disk
  4. is_floor_known() -- public helper used by orchestrator
"""
from __future__ import annotations
import logging, pickle
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from config import FAISS_TOP_K, EMBED_DIR

logger = logging.getLogger(__name__)

METADATA_FILE    = EMBED_DIR / "metadata.pkl"
VECTORIZER_FILE  = EMBED_DIR / "vectorizer.pkl"
MATRIX_FILE      = EMBED_DIR / "tfidf_matrix.npy"
KNOWN_FLOORS_FILE= EMBED_DIR / "known_floors.pkl"   # NEW: floor registry

AREA_DESCRIPTIONS = {
    "Office Space":       ["large open area workstations desks open plan corporate workspace"],
    "Open Office":        ["open plan workstations desks collaborative office"],
    "Workstation Area":   ["rows of desks workstations computers open plan"],
    "Conference Room":    ["meeting room central table chairs enclosed presentations boardroom AV"],
    "Meeting Room":       ["small meeting enclosed table chairs"],
    "Board Room":         ["large formal board table executive chairs AV"],
    "Training Room":      ["training classroom rows chairs projector"],
    "Lobby":              ["main entrance visitors reception lobby seating ground floor entry"],
    "Lift Lobby":         ["lift lobby elevator waiting area passenger lifts"],
    "Reception":          ["reception desk front desk visitors waiting"],
    "Waiting Area":       ["waiting chairs seating lounge visitors"],
    "Corridor":           ["narrow passage connecting areas circulation corridor fire exit"],
    "Fire Tower Corridor":["pressurised corridor fire tower staircase lobby"],
    "Staircase":          ["staircase floors emergency exit fire tower pressurised landing"],
    "Staircase Landing":  ["landing floor staircase level"],
    "Male Toilet":        ["male restroom urinals cubicles washbasins men toilet"],
    "Female Toilet":      ["female restroom cubicles washbasins ladies toilet"],
    "HC Toilet":          ["handicapped accessible toilet wheelchair restroom"],
    "Shower Room":        ["shower room bath changing facilities wash"],
    "Electrical Room":    ["electrical distribution switchgear panels power room"],
    "IT Room":            ["server room IT equipment racks data centre networking"],
    "IDF Room":           ["intermediate distribution frame IDF telecom room"],
    "AHU Room":           ["air handling unit HVAC mechanical equipment ventilation room"],
    "Fan Room":           ["fan room ventilation large fans air circulation mechanical"],
    "Pump Room":          ["pump room fire pumps water pumps mechanical"],
    "Janitor Room":       ["janitor storage cleaning equipment store room"],
    "Storage":            ["storage room store archive boxes"],
    "Spare Room":         ["spare room unused unallocated future provision"],
    "Service Lobby":      ["service area deliveries staff back of house BOH corridor"],
    "BOH":                ["back of house staff service area"],
    "Event Space":        ["large multipurpose event area gatherings double height hall"],
    "Parking Bay":        ["parking space vehicles car parking basement reserved bay"],
    "Driveway":           ["driveway vehicle access circulation route wide"],
    "Ramp":               ["ramp vehicle access slope gradient basement"],
    "Loading Bay":        ["loading unloading bay trucks goods receiving dock"],
    "Void":               ["void slab open floor below structural light well opening"],
    "Atrium":             ["central atrium open sky multi-storey space courtyard"],
    "Refuge Terrace":     ["refuge area terrace fire evacuation external zone slope"],
    "Landscaped Terrace": ["landscaped terrace garden outdoor planting"],
    "Security Office":    ["security guard office control room time office"],
    "DG Room":            ["diesel generator room standby power generator"],
    "Life Safety DG Room":["life safety diesel generator essential services"],
    "HV Switch Room":     ["high voltage switchgear HV electrical switch room transformer"],
    "HT Panel Room":      ["HT panel high tension electrical room"],
    "Day Tank Room":      ["day tank fuel diesel storage room"],
    "Hot Air Chamber":    ["hot air chamber exhaust generator mechanical heat"],
    "11 KV Switch Gear Room": ["11KV switchgear room high voltage panel"],
    "Transformer Room":   ["transformer room electrical step down power"],
    "Kitchen":            ["kitchen cooking equipment commercial food prep"],
    "Cafeteria":          ["cafeteria dining food service seating"],
    "Staff Room":         ["staff room rest break lounge employees"],
    "PHE Shaft":          ["public health engineering shaft duct riser"],
    "Exhaust Shaft":      ["exhaust shaft duct ventilation riser B3"],
    "HVAC Shaft":         ["HVAC shaft duct mechanical air conditioning riser"],
    "Basement Ventilation Shaft": ["basement ventilation shaft open sky air"],
    "Double Height Area": ["double height void open two floors atrium side"],
    "Garbage Sorting Area": ["garbage waste sorting recycling area"],
    "Refuse Area":        ["refuse waste collection bin area"],
    "STP Tank":           ["sewage treatment plant tank MBR aeration"],
    "Fire Water Tank":    ["fire water tank reservoir pump room"],
    "Raw Water Tank":     ["raw water tank storage reservoir"],
    "Subsoil Well":       ["subsoil well groundwater borewell"],
    "Unidentified Area":  ["unknown unlabelled region unclear unidentified space"],
}


class RAGSystem:
    def __init__(self):
        self.vectorizer   = None
        self.matrix       = None
        self.metadata     = []
        self._texts       = []
        self._known_floors: set[str] = set()   # floors already learned

    # ── public ────────────────────────────────────────────────────────────────

    def build_from_descriptions(self):
        """Build initial RAG from built-in AREA_DESCRIPTIONS (runs once)."""
        texts, meta = [], []
        for cat, descs in AREA_DESCRIPTIONS.items():
            for d in descs:
                full = f"{cat} {d}"
                texts.append(full)
                meta.append({"category": cat, "description": d})
        self._fit(texts, meta)
        logger.info("RAG built: %d entries from built-in descriptions", len(texts))

    def is_floor_known(self, floor_name: str) -> bool:
        """Return True if this floor's areas have already been learned."""
        return floor_name in self._known_floors

    def add_labeled_areas(self, areas: list[dict], floor_name: str = "") -> bool:
        """
        Learn from the labeled areas of one floor.
        If floor_name is given and already known → skip (no duplicate learning).
        Returns True if new knowledge was added, False if skipped.
        """
        if floor_name and floor_name in self._known_floors:
            logger.info("RAG: floor '%s' already learned -- skipping", floor_name)
            return False

        new_texts, new_meta = [], []
        for a in areas:
            if not a.get("has_label"):
                continue
            cat  = a.get("category", a.get("name", ""))
            name = a.get("name", "")
            if not cat:
                continue
            new_texts.append(f"{cat} {name}")
            new_meta.append({"category": cat, "name": name, "source": floor_name})

        if not new_texts:
            return False

        # Re-fit with existing + new texts
        self._fit(self._texts + new_texts, self.metadata + new_meta)

        if floor_name:
            self._known_floors.add(floor_name)

        # AUTO-SAVE so next run loads from disk (RAG built only once)
        self.save()
        logger.info(
            "RAG: learned %d areas from '%s' | total: %d entries | known floors: %d",
            len(new_texts), floor_name or "unknown",
            len(self._texts), len(self._known_floors),
        )
        return True

    def query(self, description: str, top_k: int = FAISS_TOP_K) -> list[dict]:
        if self.vectorizer is None:
            return []
        vec  = self.vectorizer.transform([description])
        sims = cosine_similarity(vec, self.matrix)[0]
        top_i= np.argsort(sims)[::-1][:top_k]
        return [
            {
                "category": self.metadata[i]["category"],
                "score":    float(sims[i]),
                "metadata": self.metadata[i],
            }
            for i in top_i
        ]

    def save(self):
        """Persist all RAG state to disk."""
        EMBED_DIR.mkdir(parents=True, exist_ok=True)
        with open(METADATA_FILE,     "wb") as f: pickle.dump(self.metadata,       f)
        with open(VECTORIZER_FILE,   "wb") as f: pickle.dump(self.vectorizer,     f)
        with open(KNOWN_FLOORS_FILE, "wb") as f: pickle.dump(self._known_floors,  f)
        np.save(str(MATRIX_FILE), self.matrix)

    def load(self) -> bool:
        """Load RAG state from disk. Returns True if successful."""
        if not (VECTORIZER_FILE.exists() and METADATA_FILE.exists() and MATRIX_FILE.exists()):
            return False
        try:
            with open(VECTORIZER_FILE, "rb") as f: self.vectorizer     = pickle.load(f)
            with open(METADATA_FILE,   "rb") as f: self.metadata       = pickle.load(f)
            self.matrix = np.load(str(MATRIX_FILE))
            # Restore known-floors registry (may not exist in old saves)
            if KNOWN_FLOORS_FILE.exists():
                with open(KNOWN_FLOORS_FILE, "rb") as f:
                    self._known_floors = pickle.load(f)
            # Restore texts list from metadata for future re-fitting
            self._texts = [
                f"{m.get('category','')} {m.get('description', m.get('name',''))}"
                for m in self.metadata
            ]
            logger.info(
                "RAG loaded: %d entries | %d floors already learned",
                len(self.metadata), len(self._known_floors),
            )
            return True
        except Exception as exc:
            logger.warning("RAG load failed (%s) -- will rebuild", exc)
            return False

    # ── private ───────────────────────────────────────────────────────────────

    def _fit(self, texts: list[str], meta: list[dict]):
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
        self.matrix     = self.vectorizer.fit_transform(texts).toarray().astype("float32")
        self.metadata   = list(meta)
        self._texts     = list(texts)
