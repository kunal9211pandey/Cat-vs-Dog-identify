"""
CAD AI Pipeline - Configuration
================================
Central config for all modules.
"""

import os
from pathlib import Path

# Load .env file FIRST so os.getenv picks up values from it
try:
    from dotenv import load_dotenv
    load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=False)
except ImportError:
    pass  # dotenv not installed – fall back to plain env vars

# ─────────────────────────────────────────────
# API Keys  (override via .env or env vars)
# ─────────────────────────────────────────────
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

# Groq model IDs
GROQ_VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"   # multimodal vision
GROQ_TEXT_MODEL   = "llama-3.3-70b-versatile"                     # planning / reasoning

# ─────────────────────────────────────────────
# Paths
# ─────────────────────────────────────────────
BASE_DIR    = Path(__file__).parent
PDF_DIR     = BASE_DIR / "data" / "pdfs"
SAMPLES_DIR = BASE_DIR / "data" / "samples"
OUTPUT_DIR  = BASE_DIR / "data" / "output"
EMBED_DIR   = BASE_DIR / "data" / "embeddings"

for _d in [PDF_DIR, SAMPLES_DIR, OUTPUT_DIR, EMBED_DIR]:
    _d.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────────────
# PDF / Image Extraction
# ─────────────────────────────────────────────
PDF_DPI          = 150          # 150 DPI → fast + clear; use 300 for print-quality
EXTRACT_FULL_RES = True

# ─────────────────────────────────────────────
# Drawing-sheet region exclusions
#
# Architectural drawings follow a standard layout:
#   • Drawing area  : left ~82%, top ~90%
#   • Riser schedule / Legend : right ~18%  ← LEGEND_X_FRAC
#   • Title block / Notes     : bottom ~9%  ← TITLE_Y_FRAC
#   • Key-plan thumbnail      : bottom-right corner (covered by both)
#
# Any text block whose bounding box STARTS beyond these thresholds
# belongs to the annotation region, not the floor plan, and must be
# excluded from area detection.
# ─────────────────────────────────────────────
LEGEND_X_FRAC = 0.82    # x-normalised: blocks starting ≥ this are in legend column
TITLE_Y_FRAC  = 0.91    # y-normalised: blocks starting ≥ this are in title/notes strip

# ─────────────────────────────────────────────
# Tiling  (multi-scale sliding window)
# ─────────────────────────────────────────────
TILE_CONFIGS = [
    {"size": 1024, "overlap": 0.20, "label": "coarse"},
    {"size": 512,  "overlap": 0.25, "label": "fine"},
]

# ─────────────────────────────────────────────
# Spatial / gap-detection settings
# ─────────────────────────────────────────────
# Minimum size of an uncovered region (as fraction of total image cells)
# before it is flagged as "Unidentified Area".
# 0.005 was too low → caught legend whitespace and margin slivers.
# 0.025 = ~2.5% of drawing area; reasonable minimum for a real room.
MIN_UNCOVERED_FRAC = 0.025

# ─────────────────────────────────────────────
# RAG / Embeddings
# ─────────────────────────────────────────────
EMBED_MODEL = "all-MiniLM-L6-v2"
FAISS_TOP_K = 5

# ─────────────────────────────────────────────
# Known area taxonomy  (used for inference + validation)
# ─────────────────────────────────────────────
KNOWN_AREAS = [
    # Office / work
    "Office Space", "Open Office", "Workstation Area", "Collaboration Zone",
    # Meeting
    "Conference Room", "Meeting Room", "Board Room", "Training Room",
    # Entry / circulation
    "Reception", "Waiting Area", "Lobby", "Lift Lobby", "Atrium Side Corridor",
    "Corridor", "Fire Tower Corridor", "Main Staircase", "Fire Tower Staircase",
    "Staircase Landing",
    # Vertical transport
    "Passenger Lift", "Service Lift", "Fire Lift",
    # Sanitary
    "Male Toilet", "Female Toilet", "HC Toilet", "Accessible Toilet",
    "Shower Room", "Shower",
    # MEP services
    "Electrical Room", "IT Room", "Server Room", "IDF Room",
    "AHU Room", "HVAC Room", "Fan Room", "Pump Room",
    "PHE Shaft", "Exhaust Shaft", "HVAC Shaft", "Atrium Exhaust Shaft",
    # Support
    "Service Lobby", "Janitor Room", "Storage", "Spare Room", "BOH",
    # Parking / movement
    "Parking Bay", "Driveway", "Ramp", "Loading Bay",
    "Basement Ventilation Shaft", "Moat Area",
    # Events / F&B
    "Atrium", "Event Space", "Double Height Area",
    "Kitchen", "Cafeteria", "Staff Room", "Staff Canteen",
    "De-boxing Room", "Sanitize Area",
    # Security / admin
    "Security Office", "Time Office", "Receiving Dock",
    "Receiving & Purchase Office",
    # Waste
    "Garbage Sorting Area", "Refuse Area", "Dry Trash Store",
    "E-Waste Store", "Organic Waste Converter",
    # Terrace / outdoor
    "Refuge Terrace", "Landscaped Terrace", "Cooling Tower Platform",
    # Electrical / HV
    "DG Room", "Life Safety DG Room", "Day Tank Room", "HV Switch Room",
    "HT Panel Room", "Transformer Room", "11 KV Switch Gear Room",
    "Hot Air Chamber",
    # Water / STP
    "Fire Water Tank", "Raw Water Tank", "Treated Water Tank",
    "Rain Water Sump", "Collection Sump",
    "STP Tank", "Aeration Tank", "Anoxic Tank", "MBR Tank",
    "Equalisation Tank", "Sludge Holding Tank",
    "Subsoil Well", "Suction Pit",
    # Structural / other
    "Void", "Light Well", "Cut Out", "Atrium",
]

# Capacity: net sq m per person
CAPACITY_RATIOS = {
    "Office Space": 7.5,      "Open Office": 6.0,    "Workstation Area": 6.0,
    "Conference Room": 2.0,   "Meeting Room": 2.0,   "Board Room": 3.0,
    "Reception": 10.0,        "Waiting Area": 5.0,   "Lobby": 5.0,
    "Lift Lobby": 0.0,        "Corridor": 0.0,       "Staircase Landing": 0.0,
    "Event Space": 2.5,       "Cafeteria": 2.0,      "Staff Room": 4.0,
    "Atrium": 3.0,            "Parking Bay": 0.0,    "Driveway": 0.0,
    "default": 10.0,
}

# Lighting: recommended fixtures per 100 sq m at 500 lux (40W LED panel ≈ 3500 lm)
LIGHTING_RATIOS = {
    "Office Space": 10,       "Open Office": 10,     "Conference Room": 8,
    "Meeting Room": 8,        "Board Room": 8,       "Lobby": 6,
    "Lift Lobby": 4,          "Corridor": 4,         "Staircase": 3,
    "Male Toilet": 6,         "Female Toilet": 6,    "HC Toilet": 6,
    "Shower Room": 6,
    "Event Space": 12,        "Cafeteria": 10,       "Kitchen": 12,
    "Parking Bay": 2,         "Driveway": 2,
    "Reception": 8,           "Waiting Area": 8,
    "Server Room": 6,         "IT Room": 6,          "Electrical Room": 4,
    "AHU Room": 3,            "Fan Room": 3,         "Pump Room": 3,
    "Service Lobby": 5,       "BOH": 5,
    "DG Room": 3,             "Day Tank Room": 3,    "HT Panel Room": 4,
    "Void": 0,                "Light Well": 0,
    "default": 6,
}

# Lux targets per category (IS 3646)
LUX_TARGETS = {
    "Office Space": 500,    "Open Office": 500,    "Conference Room": 500,
    "Meeting Room": 500,    "Board Room": 500,     "Reception": 300,
    "Lobby": 300,           "Lift Lobby": 150,     "Corridor": 100,
    "Male Toilet": 200,     "Female Toilet": 200,  "HC Toilet": 200,
    "Staircase": 150,       "Cafeteria": 300,      "Kitchen": 500,
    "Electrical Room": 200, "IT Room": 300,        "AHU Room": 150,
    "Fan Room": 150,        "Pump Room": 150,      "Event Space": 500,
    "Parking Bay": 50,      "Driveway": 50,        "Service Lobby": 200,
    "Loading Bay": 200,     "Atrium": 300,         "Refuge Terrace": 100,
    "default": 200,
}

# ─────────────────────────────────────────────
# Output / Annotation
# ─────────────────────────────────────────────
ANNOTATION_COLORS = {
    "Office Space": (70, 130, 180),      # steel blue
    "Open Office": (70, 130, 180),
    "Conference Room": (60, 179, 113),   # medium sea green
    "Meeting Room": (60, 179, 113),
    "Lobby": (255, 165, 0),              # orange
    "Lift Lobby": (255, 140, 0),
    "Corridor": (169, 169, 169),         # dark grey
    "Staircase": (210, 180, 140),        # tan
    "Toilet": (186, 85, 211),            # medium orchid
    "Male Toilet": (186, 85, 211),
    "Female Toilet": (186, 85, 211),
    "HC Toilet": (186, 85, 211),
    "Shower Room": (186, 85, 211),
    "Electrical Room": (220, 20, 60),    # crimson
    "IT Room": (220, 20, 60),
    "Server Room": (220, 20, 60),
    "AHU Room": (255, 99, 71),           # tomato
    "Fan Room": (255, 99, 71),
    "Pump Room": (255, 99, 71),
    "PHE Shaft": (255, 160, 122),
    "Parking Bay": (144, 238, 144),      # light green
    "Driveway": (200, 200, 200),
    "Event Space": (255, 215, 0),        # gold
    "Atrium": (135, 206, 235),           # sky blue
    "Void": (211, 211, 211),             # light grey
    "Light Well": (211, 211, 211),
    "Service Lobby": (255, 200, 100),
    "BOH": (200, 160, 100),
    "Unidentified Area": (255, 105, 97), # salmon/red – flagged regions
    "default": (100, 149, 237),          # cornflower blue
}

ANNOTATION_ALPHA = 0.35   # transparency of filled boxes
BOX_BORDER_WIDTH = 2
LABEL_FONT_SCALE = 0.45
LABEL_THICKNESS  = 1