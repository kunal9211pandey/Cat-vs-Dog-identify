"""
Validation Agent
================
Cross-checks all area predictions before final output.

Checks:
1. Duplicate names in same region -> merge
2. Impossible area sizes (too small / too large)
3. Capacity vs area sanity check
4. Confidence threshold gate
5. Lighting count sanity check
6. Asks LLM to do a final coherence pass on the full floor
"""

from __future__ import annotations

import logging
from typing import Any

from agents.base_agent import BaseAgent

logger = logging.getLogger(__name__)

MIN_AREA_SQM   = 1.0    # ignore boxes smaller than 1 sq m
MAX_AREA_SQM   = 5000.0 # single area > 5000 sqm is suspicious


class ValidationAgent(BaseAgent):
    ROLE = "Validation Agent"

    def validate(self, areas: list[dict], floor_name: str = "") -> list[dict]:
        """Full validation pass. Returns cleaned area list."""
        areas = self._remove_tiny_areas(areas)
        areas = self._cap_oversized_areas(areas)
        areas = self._fix_capacity_sanity(areas)
        areas = self._fix_lighting_sanity(areas)
        areas = self._llm_coherence_check(areas, floor_name)
        logger.info("[ValidationAgent] Validation done. %d areas passed.", len(areas))
        return areas

    # ── checks ────────────────────────────────────────────────────────────────

    def _remove_tiny_areas(self, areas: list[dict]) -> list[dict]:
        kept = []
        for a in areas:
            sqm = a.get("area_size_sqm", 0)
            if sqm < MIN_AREA_SQM and a.get("source") != "pdf_text":
                logger.debug("[ValidationAgent] Dropping tiny area '%s' (%.1f sqm)",
                             a.get("name"), sqm)
                continue
            kept.append(a)
        return kept

    def _cap_oversized_areas(self, areas: list[dict]) -> list[dict]:
        for a in areas:
            if a.get("area_size_sqm", 0) > MAX_AREA_SQM:
                logger.warning(
                    "[ValidationAgent] Area '%s' has implausible size %.1f sqm -- capping",
                    a.get("name"), a.get("area_size_sqm")
                )
                a["area_size_sqm"] = MAX_AREA_SQM
                a["size_warning"]  = True
        return areas

    def _fix_capacity_sanity(self, areas: list[dict]) -> list[dict]:
        for a in areas:
            cap  = a.get("capacity", {})
            sqm  = a.get("area_size_sqm", 0)
            ppl  = cap.get("persons", 0)
            # If capacity exceeds 1 person/sqm something is wrong
            if sqm > 0 and ppl > sqm:
                a["capacity"]["persons"] = int(sqm)
                a["capacity"]["notes"]  += " [capacity clamped]"
        return areas

    def _fix_lighting_sanity(self, areas: list[dict]) -> list[dict]:
        for a in areas:
            lt = a.get("lighting", {})
            n  = lt.get("recommended_fixtures", 0)
            sqm= a.get("area_size_sqm", 0)
            # More than 1 fixture per sqm is unrealistic
            if sqm > 0 and n > sqm:
                a["lighting"]["recommended_fixtures"] = max(1, int(sqm // 4))
                a["lighting"]["notes"] += " [fixtures clamped]"
        return areas

    def _llm_coherence_check(
        self, areas: list[dict], floor_name: str
    ) -> list[dict]:
        """
        Ask the text model to do a high-level sanity check on the area list.
        Returns areas with any corrections flagged.
        Only runs if there are < 60 areas (to stay within token limits).
        """
        if len(areas) > 60:
            logger.info("[ValidationAgent] Too many areas for LLM check -- skipping")
            return areas

        area_summary = "\n".join(
            f"  {i+1}. {a.get('name','?')} -- {a.get('area_size_sqm',0):.1f} sqm, "
            f"capacity={a.get('capacity',{}).get('persons',0)}, "
            f"confidence={a.get('confidence',0):.2f}"
            for i, a in enumerate(areas)
        )

        prompt = f"""You are reviewing the area list for {floor_name or 'a commercial office building floor'}.

Areas detected:
{area_summary}

Task: Identify any obvious mistakes (e.g., a 'Parking Bay' on a typical office floor,
 impossible area sizes, duplicate names for adjacent areas).
Return ONLY a JSON object:
{{
  "issues": [
    {{"area_index": 1, "issue": "description", "suggested_fix": "fix"}}
  ],
  "overall_quality": "good | acceptable | poor",
  "notes": "any general observations"
}}
If no issues found, return {{"issues": [], "overall_quality": "good", "notes": ""}}"""

        raw  = self._text_call(prompt, max_tokens=800)
        data = self._parse_json(raw)

        if not data:
            return areas

        for issue in data.get("issues", []):
            idx = issue.get("area_index", 0) - 1
            if 0 <= idx < len(areas):
                areas[idx]["validation_issue"] = issue.get("issue", "")
                areas[idx]["suggested_fix"]    = issue.get("suggested_fix", "")
                logger.info(
                    "[ValidationAgent] Issue in area #%d '%s': %s",
                    idx + 1, areas[idx].get("name"), issue.get("issue")
                )

        return areas