"""
Electrical Agent
================
Recommends lighting fixtures for each area.

Standards: IS 3646 (Indian Standard for interior lighting)
  Office (general) : 500 lux, assuming 40W LED panel (3500 lm)
  Corridors        : 100 lux
  Toilets          : 200 lux
  Meeting rooms    : 500 lux
  Cafeteria        : 300 lux
  Parking          : 50 lux
  Emergency routes : 10 lux (separate system)

Assumes ceiling height:
  Office floors  : 3.0 m
  Basement       : 3.5 m (incl. services)
"""

from __future__ import annotations

import math
import logging
from typing import Any

from agents.base_agent import BaseAgent
from config import LIGHTING_RATIOS

logger = logging.getLogger(__name__)

# Lux targets by category (IS 3646)
LUX_TARGETS: dict[str, int] = {
    "Office Space":     500,  "Open Office":       500,
    "Conference Room":  500,  "Meeting Room":      500,
    "Reception":        300,  "Lobby":             300,
    "Lift Lobby":       150,  "Corridor":          100,
    "Male Toilet":      200,  "Female Toilet":     200,
    "HC Toilet":        200,  "Staircase":         150,
    "Cafeteria":        300,  "Kitchen":           500,
    "Electrical Room":  200,  "IT Room":           300,
    "AHU Room":         150,  "Fan Room":          150,
    "Pump Room":        150,  "Event Space":       500,
    "Parking Bay":       50,  "Driveway":           50,
    "Service Lobby":    200,  "Loading Bay":       200,
    "Atrium":           300,  "Refuge Terrace":    100,
    "default":          200,
}

# Assumed luminous efficacy of one LED panel: lumens/fixture
LUMENS_PER_FIXTURE = 3500   # 40W LED panel (600x600mm)
CEILING_H          = 3.0    # metres
UF                 = 0.65   # Utilisation Factor (typical office)
MF                 = 0.80   # Maintenance Factor

# Practical caps: even at high lux, don't go beyond these per 100sqm
_MAX_FIXTURES_PER_100SQM = {
    "Office Space": 16, "Open Office": 16, "Private Office": 14,
    "Executive Office": 12, "Cabin": 10, "Workstation Area": 16,
    "Meeting Room": 12, "Board Room": 12, "Conference Room": 12,
    "Corridor": 6, "Reception": 10, "Lobby": 8, "Waiting Area": 8,
    "Male Toilet": 8, "Female Toilet": 8, "Washroom": 8,
    "Kitchen": 12, "Pantry": 10, "Cafeteria": 12,
    "Server Room": 10, "Electrical Room": 6, "AHU Room": 4,
    "default": 10,
}


class ElectricalAgent(BaseAgent):
    ROLE = "Electrical Agent"

    def recommend(self, area: dict) -> dict:
        """Add lighting recommendation to a single area dict."""
        sqm      = area.get("area_size_sqm", 0)
        category = area.get("category", area.get("name", ""))

        lux      = self._get_lux(category)
        fixtures = self._num_fixtures(sqm, lux, category)
        positions= self._grid_positions(area, fixtures)

        area["lighting"] = {
            "target_lux":        lux,
            "recommended_fixtures": fixtures,
            "fixture_type":      "40W LED Panel 600×600mm",
            "positions_norm":    positions,
            "emergency_lights":  self._emergency_lights(category, sqm),
            "standard":          "IS 3646 (Interior Lighting)",
            "notes":             self._lighting_notes(category),
        }
        return area

    def batch_recommend(self, areas: list[dict]) -> list[dict]:
        return [self.recommend(a) for a in areas]

    # ── private ───────────────────────────────────────────────────────────────

    def _get_lux(self, category: str) -> int:
        cat_up = category.upper()
        for k, v in LUX_TARGETS.items():
            if k.upper() in cat_up:
                return v
        return LUX_TARGETS["default"]

    def _num_fixtures(self, sqm: float, lux: int, category: str = "") -> int:
        if sqm <= 0 or lux <= 0:
            return 0
        # IS 3646 formula: N = (E × A) / (Φ × UF × MF)
        n = (lux * sqm) / (LUMENS_PER_FIXTURE * UF * MF)
        n = int(math.ceil(n))
        # Apply practical cap per room type
        cap_key = next((k for k in _MAX_FIXTURES_PER_100SQM if k.upper() in category.upper()), "default")
        max_per_100 = _MAX_FIXTURES_PER_100SQM[cap_key]
        cap = max(1, int(math.ceil(sqm / 100 * max_per_100)))
        return max(1, min(n, cap))

    def _grid_positions(self, area: dict, n_fixtures: int) -> list[list[float]]:
        """
        Distribute fixtures on a regular grid within the area.
        Returns list of [x_norm, y_norm] positions.
        """
        if n_fixtures == 0:
            return []
        n   = area.get("coordinates_norm", [0, 0, 1, 1])
        x1, y1, x2, y2 = n
        W = x2 - x1; H = y2 - y1

        cols = max(1, round(math.sqrt(n_fixtures * W / max(H, 0.001))))
        rows = max(1, math.ceil(n_fixtures / cols))

        positions = []
        for r in range(rows):
            for c in range(cols):
                px = round(x1 + W * (c + 0.5) / cols, 4)
                py = round(y1 + H * (r + 0.5) / rows, 4)
                positions.append([px, py])
                if len(positions) >= n_fixtures:
                    break
            if len(positions) >= n_fixtures:
                break
        return positions

    def _emergency_lights(self, category: str, sqm: float) -> int:
        """Emergency / exit lights (1 per 50 sqm in egress paths)."""
        cat_up = category.upper()
        if any(w in cat_up for w in ["CORRIDOR","STAIRCASE","LOBBY","EXIT","FIRE"]):
            return max(1, int(math.ceil(sqm / 50)))
        return 0

    def _lighting_notes(self, category: str) -> str:
        cat_up = category.upper()
        if "VOID" in cat_up or "SHAFT" in cat_up:
            return "No lighting required"
        if "PARKING" in cat_up or "DRIVEWAY" in cat_up:
            return "Low bay LED or surface-mounted IP65 fitting recommended"
        if "OFFICE" in cat_up:
            return "Consider daylight harvesting sensors near window facades"
        if "TOILET" in cat_up:
            return "Motion sensor + IP44 rated fittings recommended"
        return ""