"""
Base Agent
==========
All agents inherit from this. Provides:
  * Groq client (vision + text)
  * image -> base64 helper
  * JSON-safe Groq calls with retry + exponential backoff
  * Proper timeout handling for connection errors

FIXES vs original:
  - Added httpx timeout so calls don't hang indefinitely
  - Exponential backoff now waits longer (1s/2s/4s)
  - Vision calls resize to 1024px max (Groq limit)
  - _parse_json handles list responses as well as dicts
  - Connection errors logged with full detail for debugging
"""

from __future__ import annotations

import base64
import json
import logging
import re
import time
from io import BytesIO
from typing import Any

from groq import Groq
from PIL import Image

from config import GROQ_API_KEY, GROQ_VISION_MODEL, GROQ_TEXT_MODEL

logger = logging.getLogger(__name__)

_REQUEST_TIMEOUT = 60.0
# Minimum gap between consecutive API calls (seconds) to stay inside free-tier rate limits
_MIN_CALL_GAP   = 0.4
_last_call_ts   = 0.0   # module-level timestamp of last API call


class BaseAgent:
    ROLE   = "Base Agent"
    VISION = False   # set True in vision-capable agents

    def __init__(self, rag_system=None):
        if not GROQ_API_KEY:
            raise EnvironmentError(
                "GROQ_API_KEY is not set.\n"
                "  Windows : set GROQ_API_KEY=gsk_xxxx\n"
                "  Mac/Linux: export GROQ_API_KEY=gsk_xxxx"
            )
        self.client = Groq(api_key=GROQ_API_KEY)
        self.rag    = rag_system

    # ── helpers ───────────────────────────────────────────────────────────────

    def _image_to_b64(self, img: Image.Image, max_px: int = 1024) -> str:
        """Resize to max_px on longest side, encode to JPEG base64."""
        w, h = img.size
        if max(w, h) > max_px:
            scale = max_px / max(w, h)
            img   = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
        buf = BytesIO()
        img.convert("RGB").save(buf, format="JPEG", quality=88)
        return base64.b64encode(buf.getvalue()).decode("utf-8")

    def _vision_call(
        self,
        image:      Image.Image,
        prompt:     str,
        system:     str = "You are an expert CAD floor plan analyst.",
        max_tokens: int = 2000,
        retries:    int = 3,
    ) -> str:
        """Call Groq vision model; returns raw text."""
        b64 = self._image_to_b64(image)
        messages = [{
            "role": "user",
            "content": [
                {
                    "type":      "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{b64}"},
                },
                {"type": "text", "text": prompt},
            ],
        }]
        return self._call(GROQ_VISION_MODEL, messages, system, max_tokens, retries)

    def _text_call(
        self,
        prompt:     str,
        system:     str = "You are an expert building analyst.",
        max_tokens: int = 2000,
        retries:    int = 3,
    ) -> str:
        """Call Groq text model; returns raw text."""
        messages = [{"role": "user", "content": prompt}]
        return self._call(GROQ_TEXT_MODEL, messages, system, max_tokens, retries)

    def _call(
        self,
        model:      str,
        messages:   list,
        system:     str,
        max_tokens: int,
        retries:    int,
    ) -> str:
        """
        Groq API call with exponential-backoff retry.
        A small inter-call delay (_MIN_CALL_GAP) is enforced to avoid 429s.
        """
        global _last_call_ts
        full_messages = [{"role": "system", "content": system}] + messages

        for attempt in range(retries):
            # Throttle: enforce minimum gap between calls
            elapsed = time.time() - _last_call_ts
            if elapsed < _MIN_CALL_GAP:
                time.sleep(_MIN_CALL_GAP - elapsed)

            try:
                _last_call_ts = time.time()
                resp = self.client.chat.completions.create(
                    model       = model,
                    messages    = full_messages,
                    max_tokens  = max_tokens,
                    temperature = 0.1,
                    timeout     = _REQUEST_TIMEOUT,
                )
                content = resp.choices[0].message.content
                return content.strip() if content else ""

            except Exception as exc:
                wait = 2 ** attempt   # 1s, 2s, 4s
                exc_type = type(exc).__name__
                logger.warning(
                    "[%s] API error (attempt %d/%d): %s: %s -- retrying in %ds",
                    self.ROLE, attempt + 1, retries, exc_type, str(exc)[:120], wait,
                )
                time.sleep(wait)

        logger.error("[%s] All %d retries failed for model %s", self.ROLE, retries, model)
        return ""

    def _parse_json(self, text: str) -> Any:
        """
        Extract JSON from model response.
        Handles: markdown fences, leading/trailing prose, list responses,
        and TRUNCATED JSON (max_tokens cut the response mid-way).
        """
        if not text:
            return {}

        # Strip markdown code fences
        text = re.sub(r"```(?:json)?", "", text).strip("`").strip()

        # Try direct parse first
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        # Try to extract JSON object (greedy — may be incomplete)
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if m:
            fragment = m.group()
            try:
                return json.loads(fragment)
            except json.JSONDecodeError:
                # Truncated JSON — try to recover the fields we care about
                recovered = self._recover_truncated_json(fragment)
                if recovered:
                    return recovered

        # Try to extract JSON array
        m = re.search(r"\[.*\]", text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass

        logger.warning(
            "[%s] Could not parse JSON from: %s...",
            self.ROLE, text[:200].replace("\n", " ")
        )
        return {}

    @staticmethod
    def _recover_truncated_json(fragment: str) -> dict:
        """
        When the model's response is cut off mid-JSON (due to max_tokens),
        try to extract at least the 'name' and 'confidence' fields using regex.
        """
        result = {}
        # Extract "name": "..."
        m = re.search(r'"name"\s*:\s*"([^"]+)"', fragment)
        if m:
            result["name"] = m.group(1)
        # Extract "confidence": 0.XX
        m = re.search(r'"confidence"\s*:\s*([0-9.]+)', fragment)
        if m:
            try:
                result["confidence"] = float(m.group(1))
            except ValueError:
                pass
        # Extract "reasoning": "..." (may be partial — that's fine)
        m = re.search(r'"reasoning"\s*:\s*"([^"]*)', fragment)
        if m:
            result["reasoning"] = m.group(1)[:80]  # truncate if needed
        return result if "name" in result else {}