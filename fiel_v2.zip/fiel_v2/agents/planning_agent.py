"""
Planning Agent
==============
Estimates seating capacity and occupancy for each area
based on area size and category-specific density standards.

Standards used (NBC India + ASHRAE 62.1):
  Office Space   : 7.5 sq m / person (NBC India)
  Conference     : 2.0 sq m / person
  Cafeteria      : 2.0 sq m / person
  Reception      : 10 sq m / person
"""

from __future__ import annotations

import logging
import math
from typing import Any

from agents.base_agent import BaseAgent
from config import CAPACITY_RATIOS

logger = logging.getLogger(__name__)


class PlanningAgent(BaseAgent):
    ROLE = "Planning Agent"

    def estimate(self, area: dict) -> dict:
        """Add capacity estimate to a single area dict."""
        sqm      = area.get("area_size_sqm", 0)
        category = area.get("category", area.get("name", ""))

        ratio    = self._get_ratio(category)
        capacity = int(sqm / ratio) if ratio > 0 and sqm > 0 else 0

        area["capacity"] = {
            "persons":      capacity,
            "area_sqm":     sqm,
            "density_standard": f"{ratio} sqm/person",
            "notes": self._occupancy_notes(category, capacity),
        }
        return area

    def batch_estimate(self, areas: list[dict]) -> list[dict]:
        return [self.estimate(a) for a in areas]

    # ── private ───────────────────────────────────────────────────────────────

    def _get_ratio(self, category: str) -> float:
        cat_up = category.upper()
        for k, v in CAPACITY_RATIOS.items():
            if k.upper() in cat_up or cat_up in k.upper():
                return v
        return CAPACITY_RATIOS["default"]

    def _occupancy_notes(self, category: str, capacity: int) -> str:
        cat_up = category.upper()
        if "TOILET" in cat_up or "SHAFT" in cat_up or "RISER" in cat_up \
                or "VOID" in cat_up or "STAIRCASE" in cat_up:
            return "Non-occupiable area"
        if "PARKING" in cat_up or "DRIVEWAY" in cat_up or "RAMP" in cat_up:
            return "Vehicle area -- persons not applicable"
        if capacity == 0:
            return "Insufficient size or non-occupiable"
        return f"Estimated peak occupancy: {capacity} persons"