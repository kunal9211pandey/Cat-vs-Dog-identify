"""
Inference Agent
===============
For areas detected visually but without a clear text label, this agent:
1. Queries the RAG index for the top-k similar known areas
2. Asks Groq to pick the best match given the visual description and neighbours
3. Returns a confident area name + updated confidence score

This is what allows the system to label unlabelled regions on CAD drawings.
"""

from __future__ import annotations

import logging
from typing import Any

from agents.base_agent import BaseAgent
from rag_system import RAGSystem
from config import KNOWN_AREAS

logger = logging.getLogger(__name__)


SYSTEM_PROMPT = """You are an expert architectural space planner for commercial office buildings.
You identify room types by analysing: (1) visible text labels, (2) furniture/fixture symbols
described in the visual context, (3) room shape and size, (4) adjacent rooms.

FURNITURE → ROOM TYPE rules you MUST follow:
- Large single desk + visitor chairs               → "Private Office"
- Very large desk + sofa/coffee table              → "Executive Office"  
- Single small desk, tiny room (<15 sqm)           → "Cabin"
- Multiple L/curved workstations with partitions   → "Workstation Area"
- Large open area, many desks, no partitions       → "Open Office"
- Oval/rect table + 8+ chairs                      → "Board Room"
- Table + 4-8 chairs                               → "Meeting Room"
- Table + 2-4 chairs (small breakout)              → "Discussion Area"
- Toilet/WC/urinal/basin symbols                   → "Male Toilet" or "Female Toilet"
- Reception counter facing entry                   → "Reception"
- Kitchen sink + appliances/counter                → "Pantry" or "Kitchen"
- Server/IT racks                                  → "Server Room"
- No furniture, narrow passage                     → "Corridor"
- Waiting chairs along walls                       → "Waiting Area" """


class InferenceAgent(BaseAgent):
    ROLE = "Inference Agent"

    def __init__(self, rag_system: RAGSystem):
        super().__init__(rag_system)
        self.building_type = "corporate_office"
        self.image_type    = "3d_render"

    def infer_label(
        self,
        area: dict,
        neighbours: list[dict] | None = None,
        context_description: str = "",
    ) -> dict:
        """
        Given an area with has_label=False, infer its name.

        Parameters
        ----------
        area : dict
            Area dict from VisionAgent (has_label=False)
        neighbours : list[dict]
            Nearby areas (for spatial context)
        context_description : str
            Any additional description (e.g. floor name, zone)

        Returns
        -------
        Updated area dict with inferred name, category and confidence.
        """
        if area.get("has_label") and area.get("confidence", 0) >= 0.85:
            return area   # already confident -- skip

        # 1. Build description for RAG query
        inferred_reason = area.get("inferred_reason", "")
        visual_desc = area.get("visible_text", "") or inferred_reason or \
                      f"region at {area.get('coordinates_norm', '')}"

        neighbour_names = ", ".join(
            n.get("name", "") for n in (neighbours or []) if n.get("name")
        )

        query_text = (
            f"{visual_desc}. "
            f"Adjacent to: {neighbour_names}. "
            f"Context: {context_description}."
        )

        # 2. RAG retrieval
        similar = self.rag.query(query_text, top_k=5)
        candidates = [r["category"] for r in similar]

        # 3. LLM decision
        candidate_list = "\n".join(f"  - {c}" for c in candidates)
        known_list     = "\n".join(f"  - {k}" for k in KNOWN_AREAS[:30])

        prompt = f"""You are analysing an unlabelled region on a {self.building_type.replace('_',' ')} floor plan.
Image type: {self.image_type.replace('_',' ')}.

Furniture / objects observed inside this region: "{visual_desc}"
Neighbouring areas: {neighbour_names or 'unknown'}
Floor context: {context_description or 'typical floor of this building'}

Best candidate area types from knowledge base:
{candidate_list}

TASK: Choose the MOST SPECIFIC, ACCURATE area type based on the furniture observed.
- Use real-world knowledge of {self.building_type.replace('_',' ')} spaces
- Do NOT default to generic names if furniture gives a clear clue
- A room with kitchen counter is "Pantry", NOT "Executive Office"
- A room with bean bags is "Lounge", NOT "Discussion Area"

Return ONLY JSON — keep "reasoning" under 12 words:
{{
  "name": "Most Specific Area Name",
  "confidence": 0.85,
  "reasoning": "12 words max"
}}"""

        raw  = self._text_call(prompt, SYSTEM_PROMPT, max_tokens=150)
        data = self._parse_json(raw)

        if data and "name" in data:
            inferred_name = data["name"]
            inferred_conf = float(data.get("confidence", 0.65))
            logger.info(
                "[InferenceAgent] Inferred '%s' (conf=%.2f) for unlabelled area",
                inferred_name, inferred_conf
            )
            area = {
                **area,
                "name":             inferred_name,
                "category":         inferred_name,
                "confidence":       inferred_conf,
                "inferred":         True,
                "inference_reason": data.get("reasoning", ""),
                "rag_candidates":   candidates,
            }
        else:
            # Fallback: pick top RAG result
            if candidates:
                area = {**area, "name": candidates[0], "category": candidates[0],
                        "confidence": 0.5, "inferred": True}

        return area

    def batch_infer(
        self,
        areas: list[dict],
        floor_context: str = "",
    ) -> list[dict]:
        """Infer labels for all areas that lack confident labels."""
        updated = []
        for area in areas:
            if not area.get("has_label") or area.get("confidence", 1.0) < 0.6:
                # Find neighbours (same tile or nearby by coordinates)
                neighbours = self._find_neighbours(area, areas)
                area = self.infer_label(area, neighbours, floor_context)
            updated.append(area)
        return updated

    def _find_neighbours(
        self, area: dict, all_areas: list[dict], n: int = 5
    ) -> list[dict]:
        """Find the n closest areas by bounding-box centre."""
        cx1 = (area["coordinates_norm"][0] + area["coordinates_norm"][2]) / 2
        cy1 = (area["coordinates_norm"][1] + area["coordinates_norm"][3]) / 2

        scored = []
        for other in all_areas:
            if other is area:
                continue
            ox = (other["coordinates_norm"][0] + other["coordinates_norm"][2]) / 2
            oy = (other["coordinates_norm"][1] + other["coordinates_norm"][3]) / 2
            dist = ((cx1 - ox) ** 2 + (cy1 - oy) ** 2) ** 0.5
            scored.append((dist, other))

        scored.sort(key=lambda x: x[0])
        return [o for _, o in scored[:n]]