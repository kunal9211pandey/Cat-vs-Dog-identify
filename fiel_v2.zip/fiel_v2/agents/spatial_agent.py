"""
Spatial Agent
=============
Takes the raw area detections from Vision + PDF text and:
1. Deduplicates overlapping boxes (IoU-based NMS)
2. Merges fragmented labels for the same physical space
3. Estimates area_size_sqm from the bounding box + drawing scale
4. Ensures 100% coverage  (flags large uncovered regions)
5. Outputs a clean, non-overlapping list of areas with full coordinates

Drawing scale reference: 1:200 -> 1mm on drawing = 200mm in reality.
At 150 DPI, 1 pixel ≈ 0.169 mm -> 1 pixel ≈ 33.9 mm (real) ≈ 0.0339 m

BUG-FIX (Unidentified Area full-page bbox)
-------------------------------------------
Root causes:
  a) min_size_frac = 0.005 was far too small -> legend whitespace + border margins
     were collected into a giant BFS blob that spanned most of the page.
  b) The BFS did NOT exclude the legend/title regions -> those cells inflated blobs.
  c) No upper-bound on individual blob size -> one blob could capture the whole page.

Fixes applied:
  1. min_size_frac raised to MIN_UNCOVERED_FRAC (0.025 = 2.5% of grid cells)
  2. Legend/title regions excluded from the coverage mask (already "covered")
  3. Hard cap: any blob larger than MAX_UNCOVERED_FRAC (15%) is discarded as noise
  4. Overlap-shrink: uncovered bbox is inset by half a grid_step to avoid
     blobs that merely hug a detected area's border.
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np

from agents.base_agent import BaseAgent
from config import LEGEND_X_FRAC, TITLE_Y_FRAC, MIN_UNCOVERED_FRAC

logger = logging.getLogger(__name__)

# ─── Drawing-scale pixel->metre conversion ─────────────────────────────────────
SCALE_RATIO  = 200          # 1:200
DPI          = 150
MM_PER_INCH  = 25.4
PX_TO_MM     = MM_PER_INCH / DPI               # mm per pixel on image
PX_TO_REAL_M = PX_TO_MM * SCALE_RATIO / 1000  # metres per pixel in reality

# Hard cap: blobs larger than this fraction of grid cells are noise, not rooms
MAX_UNCOVERED_FRAC = 0.15   # 15 %


class SpatialAgent(BaseAgent):
    ROLE = "Spatial Agent"

    def __init__(self, image_size_px: tuple[int, int], rag_system=None):
        super().__init__(rag_system)
        self.W, self.H = image_size_px

    # ── public ────────────────────────────────────────────────────────────────

    def process(self, areas: list[dict]) -> list[dict]:
        """Full spatial processing pipeline."""
        areas = [self._add_pixel_coords(a) for a in areas]
        areas = self._non_max_suppression(areas, iou_threshold=0.5)
        logger.info("[SpatialAgent] After NMS: %d areas", len(areas))

        areas = [self._estimate_area_size(a) for a in areas]

        uncovered = self._find_uncovered_regions(areas)
        if uncovered:
            logger.info("[SpatialAgent] %d large uncovered regions flagged", len(uncovered))
            areas.extend(uncovered)

        # Sort: reading order (top-left -> bottom-right)
        areas.sort(key=lambda a: (a["coordinates_norm"][1], a["coordinates_norm"][0]))
        logger.info("[SpatialAgent] Final area count: %d", len(areas))
        return areas

    # ── private ───────────────────────────────────────────────────────────────

    def _add_pixel_coords(self, area: dict) -> dict:
        n = area.get("coordinates_norm", [0, 0, 1, 1])
        area["coordinates_px"] = [
            int(n[0] * self.W), int(n[1] * self.H),
            int(n[2] * self.W), int(n[3] * self.H),
        ]
        return area

    def _estimate_area_size(self, area: dict) -> dict:
        px = area.get("coordinates_px", [0, 0, self.W, self.H])
        w_real = (px[2] - px[0]) * PX_TO_REAL_M
        h_real = (px[3] - px[1]) * PX_TO_REAL_M
        area["area_size_sqm"] = round(w_real * h_real, 1)
        return area

    def _iou(self, a: list, b: list) -> float:
        xi1 = max(a[0], b[0]); yi1 = max(a[1], b[1])
        xi2 = min(a[2], b[2]); yi2 = min(a[3], b[3])
        inter = max(0, xi2 - xi1) * max(0, yi2 - yi1)
        area_a = max(1, (a[2] - a[0]) * (a[3] - a[1]))
        area_b = max(1, (b[2] - b[0]) * (b[3] - b[1]))
        return inter / (area_a + area_b - inter)

    def _containment(self, inner: list, outer: list) -> float:
        """Fraction of 'inner' box area that lies inside 'outer' box."""
        xi1 = max(inner[0], outer[0]); yi1 = max(inner[1], outer[1])
        xi2 = min(inner[2], outer[2]); yi2 = min(inner[3], outer[3])
        inter      = max(0, xi2-xi1) * max(0, yi2-yi1)
        area_inner = max(1, (inner[2]-inner[0]) * (inner[3]-inner[1]))
        return inter / area_inner

    def _non_max_suppression(
        self, areas: list[dict], iou_threshold: float = 0.30
    ) -> list[dict]:
        """
        Aggressive NMS:
        1. IoU > 0.30  → suppress lower-confidence duplicate
        2. Containment > 0.75  → if box A is 75%+ inside box B, suppress A
        This removes the severe overlapping boxes seen in 3D-render analysis.
        """
        def priority(a: dict) -> int:
            src = a.get("source", "")
            if "pdf_text" in src: return 3
            if "vision"   in src: return 2
            return 1

        areas = sorted(
            areas,
            key=lambda a: (priority(a), a.get("confidence", 0)),
            reverse=True,
        )

        kept       = []
        suppressed = [False] * len(areas)

        for i, a in enumerate(areas):
            if suppressed[i]:
                continue
            kept.append(a)
            px_a = a.get("coordinates_px", [0, 0, 10, 10])
            for j in range(i + 1, len(areas)):
                if suppressed[j]:
                    continue
                px_b = areas[j].get("coordinates_px", [0, 0, 10, 10])
                if self._iou(px_a, px_b) > iou_threshold:
                    suppressed[j] = True
                    continue
                # Also suppress if box_b is mostly swallowed by box_a
                if self._containment(px_b, px_a) > 0.75:
                    suppressed[j] = True

        return kept

    def _find_uncovered_regions(
        self,
        areas: list[dict],
        min_size_frac: float | None = None,
        grid_step: int = 50,
    ) -> list[dict]:
        """
        Raster-scan the floor-plan area (excluding legend/title zones) and
        find large gaps that are not covered by any detected region.

        Key changes vs original:
          • Legend column  (x ≥ LEGEND_X_FRAC * W) pre-marked as "covered"
          • Title strip    (y ≥ TITLE_Y_FRAC  * H) pre-marked as "covered"
          • min_size_frac raised to MIN_UNCOVERED_FRAC (2.5 %)
          • Hard cap at MAX_UNCOVERED_FRAC (15 %) to reject whole-page blobs
          • Inset bbox by ½ grid_step to avoid border-hugging artefacts
        """
        if min_size_frac is None:
            min_size_frac = MIN_UNCOVERED_FRAC

        GW = self.W // grid_step + 1
        GH = self.H // grid_step + 1

        covered = np.zeros((GH, GW), dtype=bool)

        # ── Pre-mask legend / title zones ──────────────────────────────────────
        legend_col = int(LEGEND_X_FRAC * self.W / grid_step)
        title_row  = int(TITLE_Y_FRAC  * self.H / grid_step)
        covered[:, legend_col:] = True   # right legend column
        covered[title_row:, :]  = True   # bottom title strip

        # ── Mark detected areas as covered ────────────────────────────────────
        for a in areas:
            px = a.get("coordinates_px", [])
            if len(px) < 4:
                continue
            r1 = max(0, px[1] // grid_step)
            r2 = min(GH, px[3] // grid_step + 1)
            c1 = max(0, px[0] // grid_step)
            c2 = min(GW, px[2] // grid_step + 1)
            covered[r1:r2, c1:c2] = True

        # ── BFS over uncovered cells ───────────────────────────────────────────
        total_cells = GH * GW
        min_cells   = int(min_size_frac * total_cells)
        max_cells   = int(MAX_UNCOVERED_FRAC * total_cells)

        visited    = np.zeros_like(covered, dtype=bool)
        uncovered_regions: list[dict] = []

        for start_r in range(GH):
            for start_c in range(GW):
                if covered[start_r, start_c] or visited[start_r, start_c]:
                    continue

                # BFS
                stack = [(start_r, start_c)]
                cells: list[tuple[int, int]] = []

                while stack:
                    r, c = stack.pop()
                    if r < 0 or r >= GH or c < 0 or c >= GW:
                        continue
                    if covered[r, c] or visited[r, c]:
                        continue
                    visited[r, c] = True
                    cells.append((r, c))

                    # Early exit: already too large -> noise, discard
                    if len(cells) > max_cells:
                        break

                    stack += [(r+1,c),(r-1,c),(r,c+1),(r,c-1)]

                n = len(cells)
                if n < min_cells or n > max_cells:
                    continue   # too small (sliver) or too large (noise/margin)

                rows = [rc[0] for rc in cells]
                cols = [rc[1] for rc in cells]

                # Pixel bounds -- inset by half a grid step to avoid border-hugging
                half = grid_step // 2
                x1 = min(cols) * grid_step + half
                y1 = min(rows) * grid_step + half
                x2 = min(max(cols) * grid_step + grid_step - half, self.W)
                y2 = min(max(rows) * grid_step + grid_step - half, self.H)

                if x2 <= x1 or y2 <= y1:
                    continue

                uncovered_regions.append({
                    "name":             "Unidentified Area",
                    "category":         "Unidentified Area",
                    "coordinates_px":   [x1, y1, x2, y2],
                    "coordinates_norm": [
                        round(x1 / self.W, 4), round(y1 / self.H, 4),
                        round(x2 / self.W, 4), round(y2 / self.H, 4),
                    ],
                    "has_label":        False,
                    "confidence":       0.3,
                    "source":           "spatial_gap_detection",
                    "area_size_sqm":    round(
                        (x2 - x1) * PX_TO_REAL_M * (y2 - y1) * PX_TO_REAL_M, 1
                    ),
                })

        return uncovered_regions