"""
Vision Agent  (v3 — Building-type aware, external knowledge, 3D-render aware)
=============
Key improvements:
  1. detect_building_and_image_type() — called ONCE on full image first
     → identifies building type (office/school/hospital/etc.) + 2D CAD vs 3D render
  2. TILE_PROMPT is DYNAMIC — built per-analysis with building-specific room lists
  3. External knowledge for 8 building types baked into furniture hints
  4. Zoom+rotate: only 2 rotations and 2 zoom levels (avoids 429 rate limits)
"""

from __future__ import annotations
import logging
from typing import Any
from PIL import Image
from agents.base_agent import BaseAgent
from preprocessor import Tile, zoom_region

logger = logging.getLogger(__name__)

_ROTATIONS   = [0, 90]
_ZOOM_LEVELS = [1, 2]

# ── External knowledge base ────────────────────────────────────────────────────

BUILDING_KNOWLEDGE = {
    "corporate_office": {
        "description": "Corporate / commercial office building",
        "expected_areas": [
            "Reception", "Waiting Area", "Executive Office", "Private Office",
            "Cabin", "Open Office", "Workstation Area", "Hot Desk Area",
            "Meeting Room", "Board Room", "Conference Room", "Discussion Area",
            "Lounge", "Breakout Zone", "Pantry", "Kitchen", "Cafeteria",
            "Male Toilet", "Female Toilet", "Washroom", "HC Toilet",
            "Corridor", "Staircase", "Lift Lobby", "Server Room",
            "Electrical Room", "Security Station", "Storage Room",
            "Print Room", "Training Room",
        ],
        "furniture_hints": """
FURNITURE / OBJECTS SEEN  →  EXACT ROOM NAME (use these names precisely):

  Kitchen counter + dark marble top + sink + small coloured chair    → "Pantry"
  Kitchen counter + cooking appliances + stove                       → "Kitchen"
  Very large dark desk + sofa set + coffee table (executive layout)  → "Executive Office"
  Single large desk + 2 visitor chairs across the desk               → "Private Office"
  One small desk only, tiny room (< 12 sqm visible area)            → "Cabin"
  Multiple L-shaped or straight desks with laptops/monitors          → "Workstation Area"
  Large open floor, many individual desks+chairs scattered           → "Open Office" or "Hot Desk Area"
  Long rectangular table, 8+ chairs arranged all around it          → "Board Room"
  Medium rectangular/round table, 4-8 chairs                        → "Meeting Room"
  Very small table or no table, 2-4 chairs (glass enclosure/booth)  → "Discussion Area" or "Focus Room"
  Sofas or couches + coffee table (near entrance or open area)       → "Waiting Area" or "Reception Lounge"
  Reception/service counter with monitor facing visitors             → "Reception" or "Security Station"
  Bean bags / poufs / casual floor cushions                          → "Lounge" or "Breakout Zone"
  Toilet bowl + urinals + wash basins (white sanitary fixtures)      → "Male Toilet" or "Female Toilet"
  Single toilet + basin in small closed room                         → "Washroom"
  Staircase steps + handrail visible going up/down                   → "Staircase"
  Server racks / IT equipment cabinets                               → "Server Room"
  Electrical panels / distribution boards                            → "Electrical Room"
  Shelves / filing cabinets only (no desk or seating)               → "Storage Room"
  Exercise equipment / treadmill / gym weights                       → "Gym" or "Fitness Room"
  Narrow connecting passage with no furniture                        → "Corridor"
""",
    },
    "school_college": {
        "description": "School or college / university building",
        "expected_areas": [
            "Classroom", "Laboratory", "Computer Lab", "Library",
            "Principal's Office", "Staff Room", "HOD Office",
            "Canteen", "Cafeteria", "Assembly Hall", "Auditorium",
            "Gymnasium", "Male Toilet", "Female Toilet",
            "Corridor", "Staircase", "Reception", "Waiting Area",
            "Store Room", "Examination Hall", "Seminar Hall",
        ],
        "furniture_hints": """
FURNITURE / OBJECTS SEEN  →  EXACT ROOM NAME:
  Rows of student desks facing a board/screen/projector              → "Classroom"
  Lab benches + stools + scientific equipment or chemicals           → "Laboratory"
  Rows of computers on long benches                                  → "Computer Lab"
  Shelves of books + reading/study tables                            → "Library"
  Large stage + audience seating rows                                → "Auditorium" or "Assembly Hall"
  Single executive desk + credentials/certificates on wall           → "Principal's Office"
  Multiple teacher desks grouped together                            → "Staff Room"
  Canteen tables + chairs + food service counter                     → "Canteen"
  Gym equipment / sports mats / basketball                           → "Gymnasium"
  Toilet/urinal/basin fixtures                                       → "Male Toilet" or "Female Toilet"
  Staircase with steps                                               → "Staircase"
  Narrow connecting passage                                          → "Corridor"
""",
    },
    "hospital_clinic": {
        "description": "Hospital, clinic or medical facility",
        "expected_areas": [
            "Patient Ward", "ICU", "Operation Theatre", "Doctor's Cabin",
            "Nurse Station", "Reception", "Waiting Area", "Pharmacy",
            "Laboratory", "Radiology", "Emergency Room", "Consultation Room",
            "Male Toilet", "Female Toilet", "Sluice Room",
            "Storage", "Corridor", "Staircase", "Lift Lobby",
        ],
        "furniture_hints": """
FURNITURE / OBJECTS SEEN  →  EXACT ROOM NAME:
  Hospital beds (white + railings) in rows                           → "Patient Ward"
  Single bed + monitoring equipment + IV stand                       → "ICU" or "Private Room"
  Operating table + surgical overhead lights                         → "Operation Theatre"
  Nurse counter/station + medication trays                           → "Nurse Station"
  Reception counter + rows of waiting chairs                         → "Reception" + "Waiting Area"
  Medicine shelves + dispensing counter                              → "Pharmacy"
  Diagnostic/imaging machines                                        → "Radiology" or "Laboratory"
  Doctor's desk + patient examination couch                          → "Doctor's Cabin"
  Toilet/basin fixtures                                              → "Patient Toilet" or "Washroom"
  Staircase                                                          → "Staircase"
""",
    },
    "hotel": {
        "description": "Hotel or hospitality building",
        "expected_areas": [
            "Guest Room", "Suite", "Reception", "Lobby",
            "Restaurant", "Bar", "Kitchen", "Banquet Hall",
            "Conference Room", "Gym", "Spa",
            "Male Toilet", "Female Toilet", "Staircase", "Corridor",
        ],
        "furniture_hints": """
FURNITURE / OBJECTS SEEN  →  EXACT ROOM NAME:
  Bed + wardrobe + attached bathroom                                 → "Guest Room" or "Suite"
  Grand reception desk + large lobby seating                         → "Hotel Lobby" or "Reception"
  Dining tables + service counter                                    → "Restaurant"
  Bar counter + bar stools + liquor display                          → "Bar"
  Commercial kitchen appliances                                      → "Kitchen"
  Long banquet/event table setup                                     → "Banquet Hall"
  Gym equipment                                                      → "Gym"
  Massage tables                                                     → "Spa"
  Staircase                                                          → "Staircase"
  Connecting hotel corridor                                          → "Corridor"
""",
    },
    "retail_mall": {
        "description": "Retail store, mall or shopping centre",
        "expected_areas": [
            "Sales Floor", "Trial Room", "Cash Counter",
            "Manager's Office", "Stock Room", "Staff Room",
            "Male Toilet", "Female Toilet", "Corridor", "Staircase",
        ],
        "furniture_hints": """
FURNITURE / OBJECTS SEEN  →  EXACT ROOM NAME:
  Display racks + mannequins                                         → "Sales Floor"
  Individual curtained cubicles with mirrors                         → "Trial Room"
  Cash register / POS counter                                        → "Cash Counter"
  Storage shelves + boxes                                            → "Stock Room"
  Manager desk + office chair                                        → "Manager's Office"
  Staff lockers + break table                                        → "Staff Room"
  Toilet fixtures                                                    → "Toilet"
  Staircase / escalator                                              → "Staircase"
""",
    },
    "residential": {
        "description": "Apartment, house or residential building",
        "expected_areas": [
            "Living Room", "Bedroom", "Master Bedroom", "Kitchen",
            "Dining Room", "Bathroom", "Toilet", "Balcony",
            "Pooja Room", "Study Room", "Store Room", "Staircase", "Corridor",
        ],
        "furniture_hints": """
FURNITURE / OBJECTS SEEN  →  EXACT ROOM NAME:
  Sofa + TV unit + coffee table                                      → "Living Room"
  Double bed + wardrobes + side tables                               → "Master Bedroom" or "Bedroom"
  Single bed + study table                                           → "Children's Room" or "Bedroom"
  Kitchen counter + sink + stove + fridge                            → "Kitchen"
  Dining table + chairs                                              → "Dining Room"
  Bathtub or shower + toilet + basin                                 → "Bathroom"
  Only toilet + basin (no bath)                                      → "Toilet"
  Pooja shelf / idol stand                                           → "Pooja Room"
  Study desk + bookshelves                                           → "Study Room"
  Storage shelves only                                               → "Store Room"
  Staircase                                                          → "Staircase"
  Open terrace / railing                                             → "Balcony"
""",
    },
    "temple_religious": {
        "description": "Temple, mosque, church or religious building",
        "expected_areas": [
            "Sanctum Sanctorum", "Mandap", "Prayer Hall",
            "Antechamber", "Priest's Room", "Office",
            "Prasad Counter", "Shoe Rack Area", "Washroom", "Staircase",
        ],
        "furniture_hints": """
FURNITURE / OBJECTS SEEN  →  EXACT ROOM NAME:
  Central idol/altar + enclosed inner chamber                        → "Sanctum Sanctorum"
  Large open hall, devotee seating, facing altar                     → "Mandap" or "Prayer Hall"
  Connecting hall before sanctum                                     → "Antechamber"
  Priest's desk + pooja items                                        → "Priest's Room"
  Counter for prasad / offerings                                     → "Prasad Counter"
  Shoe/slipper storage racks at entrance                             → "Shoe Rack Area"
  Toilet + basin                                                     → "Washroom"
  Staircase                                                          → "Staircase"
""",
    },
    "industrial_warehouse": {
        "description": "Factory, warehouse or industrial facility",
        "expected_areas": [
            "Production Floor", "Assembly Line", "Quality Control",
            "Warehouse", "Loading Bay", "Control Room",
            "Manager's Office", "Break Room", "Canteen",
            "Male Toilet", "Female Toilet", "Electrical Room",
            "Corridor", "Staircase",
        ],
        "furniture_hints": """
FURNITURE / OBJECTS SEEN  →  EXACT ROOM NAME:
  Machines + conveyor belts + workbenches                            → "Production Floor"
  Testing equipment + inspection tables                              → "Quality Control"
  Large open area with racking/pallets                               → "Warehouse"
  Loading dock + truck access                                        → "Loading Bay"
  Control panels + monitors + operator chairs                        → "Control Room"
  Break table + lockers                                              → "Break Room"
  Canteen furniture + food counter                                   → "Canteen"
  Toilet fixtures                                                    → "Toilet"
  Electrical panels                                                  → "Electrical Room"
  Staircase                                                          → "Staircase"
""",
    },
}

# ── System prompt ──────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """\
You are an expert architectural analyst with encyclopaedic real-world knowledge of ALL building
types — offices, schools, hospitals, hotels, temples, factories, residences, malls, etc.

You identify every enclosed space by using:
  1. Visible text labels (highest priority)
  2. Furniture and fixture objects visible inside each space
  3. Your external knowledge of how spaces look in real buildings globally
  4. Spatial context from adjacent spaces

You work on BOTH 2D CAD line drawings AND 3D rendered floor plan images.\
"""

BUILDING_DETECT_PROMPT = """\
Carefully examine this COMPLETE floor plan image.

Determine:
1. What TYPE of building is this?
   Options: corporate_office / school_college / hospital_clinic / hotel /
            retail_mall / residential / temple_religious / industrial_warehouse / unknown
2. Is this a 3D rendered image or a 2D CAD line drawing?
3. Your confidence (0.0 to 1.0)
4. The 3 strongest visual clues for your answer
5. Every distinct enclosed space you can see (name + where it is roughly located)

Return ONLY valid JSON — no prose, no code fences:
{
  "building_type": "corporate_office",
  "image_type": "3d_render",
  "confidence": 0.95,
  "clues": ["pantry with kitchen counter top-left", "conference table center", "staircase top-right"],
  "areas_glimpsed": [
    {"name": "Pantry",         "location": "top-left enclosed room with dark countertop"},
    {"name": "Workstation Area","location": "left half, multiple L-desks with laptops"},
    {"name": "Lounge",         "location": "bottom-left, bean bags and plants"},
    {"name": "Conference Room","location": "center-top, long table many chairs"},
    {"name": "Waiting Area",   "location": "bottom-center, sofas and coffee table"},
    {"name": "Staircase",      "location": "top-right corner, visible steps and handrail"},
    {"name": "Washroom",       "location": "right side, toilet and basin fixtures"}
  ]
}
"""


def _build_tile_prompt(building_type: str, image_type: str) -> str:
    kb = BUILDING_KNOWLEDGE.get(building_type, BUILDING_KNOWLEDGE["corporate_office"])
    areas_list     = "\n".join(f"  • {a}" for a in kb["expected_areas"])
    furniture_hints = kb["furniture_hints"]
    bldg_desc      = kb["description"]

    if image_type == "3d_render":
        image_guidance = (
            "IMPORTANT: This is a 3D RENDERED floor plan (top-down perspective with 3D objects).\n"
            "• Identify room boundaries from 3D wall structures and floor textures\n"
            "• Read furniture objects to identify room purpose — this is critical\n"
            "• Walls appear as thick 3D grey/white structures\n"
            "• Do NOT look for '2D thick line = wall' — look at actual 3D room contents"
        )
    else:
        image_guidance = (
            "IMPORTANT: This is a 2D CAD architectural floor plan.\n"
            "• Walls are thick solid lines; partitions are thinner\n"
            "• Room names are printed as text inside each space\n"
            "• Symbols represent furniture and fixtures"
        )

    return f"""\
This tile is cropped from a floor plan of a: {bldg_desc}

{image_guidance}

━━━ YOUR TASK ━━━
STEP 1: Scan EVERY enclosed space in this tile — even tiny ones (toilets, store rooms, shafts).
STEP 2: For each space, identify its name using:
  (a) Visible text label inside the space → use it exactly as shown
  (b) Furniture / objects visible → use the mapping below
  (c) Your real-world knowledge of {bldg_desc} layouts

━━━ EXPECTED AREA TYPES for this building ━━━
{areas_list}

━━━ FURNITURE → ROOM NAME MAPPING (follow these strictly) ━━━
{furniture_hints}

━━━ ALSO RECORD for each area ━━━
  • furniture_observed : brief list of what you see inside (e.g. "large desk, 2 visitor chairs")
  • seat_count         : number of seats/people you can count (0 if not applicable)

━━━ OUTPUT FORMAT — ONLY valid JSON, NO markdown fences ━━━
{{
  "tile_description": "one-line summary of what this tile shows",
  "areas": [
    {{
      "name": "Exact Name from the list above",
      "coordinates": [x1, y1, x2, y2],
      "has_label": true,
      "visible_text": "exact label if visible, else empty string",
      "furniture_observed": "desk, chairs, laptop, etc.",
      "seat_count": 0,
      "inferred_reason": "brief reason if inferred",
      "confidence": 0.9
    }}
  ]
}}

RULES:
• confidence = 1.0  → clear text label present
• confidence = 0.80–0.95 → furniture clearly identifies the space
• confidence = 0.50–0.79 → uncertain
• Coordinates MUST be integers within this tile's pixel dimensions
• Do NOT miss any enclosed space
• Do NOT call a Pantry "Executive Office" — use furniture clues!
• Do NOT collapse everything into generic "Office Space"\
"""


def _build_zoom_prompt(building_type: str) -> str:
    kb = BUILDING_KNOWLEDGE.get(building_type, BUILDING_KNOWLEDGE["corporate_office"])
    furniture_hints = kb["furniture_hints"]
    return f"""\
This is a ZOOMED-IN crop of a region with no clear label. Use real-world knowledge to identify it.

{furniture_hints}

Return ONLY valid JSON:
{{
  "areas": [
    {{
      "name": "Specific Room Name",
      "coordinates": [x1, y1, x2, y2],
      "has_label": false,
      "visible_text": "",
      "furniture_observed": "what you see",
      "seat_count": 0,
      "inferred_reason": "brief reasoning",
      "confidence": 0.85
    }}
  ]
}}

If nothing identifiable: {{"areas": []}}\
"""


class VisionAgent(BaseAgent):
    ROLE   = "Vision Agent"
    VISION = True

    def __init__(self, rag_system=None):
        super().__init__(rag_system)
        self.building_type            = "corporate_office"
        self.image_type               = "3d_render"
        self.building_areas_glimpsed  = []
        self._tile_prompt  = _build_tile_prompt(self.building_type, self.image_type)
        self._zoom_prompt  = _build_zoom_prompt(self.building_type)

    # ── Building detection ────────────────────────────────────────────────────

    def detect_building_and_image_type(self, full_image: Image.Image) -> dict:
        """
        Analyse the full image to detect building type + 2D-CAD vs 3D-render.
        Called ONCE before tile analysis. Updates self.building_type and rebuilds prompts.
        """
        logger.info("[VisionAgent] Step 0: Detecting building type from full image...")
        raw  = self._vision_call(
            image=full_image, prompt=BUILDING_DETECT_PROMPT,
            system=SYSTEM_PROMPT, max_tokens=1000,
        )
        data = self._parse_json(raw)
        if not isinstance(data, dict):
            logger.warning("[VisionAgent] Building detection returned no JSON — using defaults")
            return {}

        self.building_type           = data.get("building_type", "corporate_office")
        self.image_type              = data.get("image_type",    "3d_render")
        self.building_areas_glimpsed = data.get("areas_glimpsed", [])

        self._tile_prompt = _build_tile_prompt(self.building_type, self.image_type)
        self._zoom_prompt = _build_zoom_prompt(self.building_type)

        logger.info(
            "[VisionAgent] Detected: type=%-22s | render=%-8s | conf=%.2f | %d areas glimpsed",
            self.building_type, self.image_type,
            float(data.get("confidence", 0)), len(self.building_areas_glimpsed),
        )
        for a in self.building_areas_glimpsed:
            logger.info("  → %-28s at %s", a.get("name","?"), a.get("location","?"))
        return data

    # ── Tile analysis ─────────────────────────────────────────────────────────

    def analyze_tile(self, tile: Tile) -> list[dict]:
        W_tile, H_tile = tile.image.size
        raw  = self._vision_call(
            image=tile.image, prompt=self._tile_prompt,
            system=SYSTEM_PROMPT, max_tokens=2000,
        )
        data = self._parse_json(raw)
        if not data or "areas" not in data:
            logger.warning("[VisionAgent] No structured output: tile r%d c%d (%s)",
                           tile.row, tile.col, tile.scale)
            return []
        enriched = self._enrich_areas(data.get("areas", []), tile, W_tile, H_tile)
        logger.info("[VisionAgent] Tile r%d c%d (%s): %d areas",
                    tile.row, tile.col, tile.scale, len(enriched))
        return enriched

    # ── Zoom + rotate for unlabelled regions ─────────────────────────────────

    def analyze_region_with_zoom_rotate(
        self, full_image: Image.Image,
        x1_n: float, y1_n: float, x2_n: float, y2_n: float,
    ) -> list[dict]:
        W, H = full_image.size
        for zoom in _ZOOM_LEVELS:
            zoomed = zoom_region(full_image, x1_n, y1_n, x2_n, y2_n, upscale_to=1024)
            for rot in _ROTATIONS:
                candidate = zoomed.rotate(rot, expand=True) if rot else zoomed
                raw  = self._vision_call(image=candidate, prompt=self._zoom_prompt,
                                         system=SYSTEM_PROMPT, max_tokens=600)
                data = self._parse_json(raw)
                areas_raw = data.get("areas", []) if isinstance(data, dict) else []
                good = [a for a in areas_raw
                        if a.get("confidence", 0) >= 0.55
                        and a.get("name", "").strip()
                        and a.get("name", "").lower() not in ("unknown", "")]
                if good:
                    logger.info("[VisionAgent] Zoom %dx rot %d: %d areas "
                                "(%.2f,%.2f->%.2f,%.2f)",
                                zoom, rot, len(good), x1_n, y1_n, x2_n, y2_n)
                    return self._remap_zoom_coords(
                        good, x1_n, y1_n, x2_n, y2_n, W, H, candidate.size, rot)
        return []

    def analyze_full_image(self, image: Image.Image) -> list[str]:
        raw  = self._vision_call(image, BUILDING_DETECT_PROMPT, SYSTEM_PROMPT, 800)
        data = self._parse_json(raw)
        return data.get("areas_glimpsed", []) if isinstance(data, dict) else []

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _enrich_areas(self, areas_raw, tile, W_tile, H_tile):
        enriched = []
        for area in areas_raw:
            try:
                tx1, ty1, tx2, ty2 = [int(v) for v in area["coordinates"]]
                tx1 = max(0, min(tx1, W_tile)); ty1 = max(0, min(ty1, H_tile))
                tx2 = max(0, min(tx2, W_tile)); ty2 = max(0, min(ty2, H_tile))
                if tx2 <= tx1 or ty2 <= ty1:
                    continue
                coords_full = tile.tile_bbox_to_norm(tx1, ty1, tx2, ty2)
                enriched.append({
                    "name":               area.get("name", "Unknown"),
                    "category":           area.get("name", "Unknown"),
                    "coordinates_norm":   coords_full,
                    "coordinates_tile":   [tx1, ty1, tx2, ty2],
                    "has_label":          bool(area.get("has_label", False)),
                    "visible_text":       area.get("visible_text", ""),
                    "furniture_observed": area.get("furniture_observed", ""),
                    "seat_count":         int(area.get("seat_count", 0)),
                    "inferred_reason":    area.get("inferred_reason", ""),
                    "confidence":         float(area.get("confidence", 0.7)),
                    "source":             "vision_agent",
                    "tile_scale":         tile.scale,
                    "tile_row":           tile.row,
                    "tile_col":           tile.col,
                    "building_type":      self.building_type,
                })
            except (KeyError, ValueError, TypeError) as exc:
                logger.debug("[VisionAgent] Skipping malformed area: %s (%s)", area, exc)
        return enriched

    def _remap_zoom_coords(self, areas, x1_n, y1_n, x2_n, y2_n,
                           W_full, H_full, zoom_img_size, rotation):
        rw, rh  = zoom_img_size
        reg_x1  = int(x1_n * W_full); reg_y1 = int(y1_n * H_full)
        reg_x2  = int(x2_n * W_full); reg_y2 = int(y2_n * H_full)
        reg_w   = max(1, reg_x2 - reg_x1)
        reg_h   = max(1, reg_y2 - reg_y1)
        results = []
        for area in areas:
            try:
                cx1, cy1, cx2, cy2 = [int(v) for v in area.get("coordinates",[0,0,rw,rh])]
                cx1=max(0,min(cx1,rw)); cy1=max(0,min(cy1,rh))
                cx2=max(0,min(cx2,rw)); cy2=max(0,min(cy2,rh))
                cx1,cy1 = _unrotate_point(cx1,cy1,rw,rh,rotation)
                cx2,cy2 = _unrotate_point(cx2,cy2,rw,rh,rotation)
                ux1,uy1 = min(cx1,cx2), min(cy1,cy2)
                ux2,uy2 = max(cx1,cx2), max(cy1,cy2)
                px1 = reg_x1 + int(ux1/rw*reg_w); py1 = reg_y1 + int(uy1/rh*reg_h)
                px2 = reg_x1 + int(ux2/rw*reg_w); py2 = reg_y1 + int(uy2/rh*reg_h)
                px1=max(0,min(px1,W_full)); py1=max(0,min(py1,H_full))
                px2=max(0,min(px2,W_full)); py2=max(0,min(py2,H_full))
                norm = [round(px1/W_full,4), round(py1/H_full,4),
                        round(px2/W_full,4), round(py2/H_full,4)]
                results.append({
                    "name":               area.get("name","Unknown"),
                    "category":           area.get("name","Unknown"),
                    "coordinates_norm":   norm,
                    "has_label":          bool(area.get("has_label",True)),
                    "visible_text":       area.get("visible_text",""),
                    "furniture_observed": area.get("furniture_observed",""),
                    "seat_count":         int(area.get("seat_count",0)),
                    "inferred_reason":    area.get("inferred_reason",""),
                    "confidence":         float(area.get("confidence",0.7)),
                    "source":             "vision_zoom_rotate",
                    "building_type":      self.building_type,
                })
            except Exception as exc:
                logger.debug("[VisionAgent] Zoom remap error: %s", exc)
        return results


def _unrotate_point(x, y, img_w, img_h, rotation):
    if rotation == 0:   return x, y
    if rotation == 90:  return y, img_w - x
    if rotation == 180: return img_w-x, img_h-y
    if rotation == 270: return img_h-y, x
    return x, y