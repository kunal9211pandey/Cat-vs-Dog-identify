"""
OCR Agent
=========
Extracts text labels from image tiles using the vision model as an
"AI-OCR" -- more accurate than Tesseract on dense technical drawings.

This agent focuses on text extraction only, not spatial understanding.
Results are used by the Inference Agent to improve area names.
"""

from __future__ import annotations

import logging
import re

from PIL import Image

from agents.base_agent import BaseAgent
from preprocessor import Tile

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are an expert OCR system specialised in architectural drawings.
You can read all types of text in CAD floor plans: room labels, dimensions,
riser codes, and annotations, even when they are small or rotated."""

OCR_PROMPT = """Carefully read ALL text visible in this CAD floor plan tile.
Return ONLY a JSON object in this exact format:
{
  "labels": [
    {
      "text": "exact text as written",
      "approximate_position": "top-left | top-center | top-right | middle-left | center | middle-right | bottom-left | bottom-center | bottom-right",
      "type": "room_label | riser_code | dimension | annotation | other"
    }
  ]
}

Rules:
- Include EVERY piece of text you can see
- 'room_label' = area names like OFFICE SPACE, LIFT LOBBY, MALE TOILET, etc.
- 'riser_code' = codes like R1, R14, R9B, etc.
- 'dimension'  = numbers, FFL+xxx, measurements
- Preserve exact capitalisation and spacing
"""


class OCRAgent(BaseAgent):
    ROLE   = "OCR Agent"
    VISION = True

    def extract_text(self, tile: Tile) -> list[dict]:
        """Extract all text from a tile. Returns list of label dicts."""
        raw  = self._vision_call(
            image      = tile.image,
            prompt     = OCR_PROMPT,
            system     = SYSTEM_PROMPT,
            max_tokens = 1000,
        )
        data = self._parse_json(raw)
        if not data or "labels" not in data:
            return []

        labels = []
        for lbl in data.get("labels", []):
            text = lbl.get("text", "").strip()
            if not text or len(text) < 2:
                continue
            labels.append({
                "text":     text,
                "position": lbl.get("approximate_position", "unknown"),
                "type":     lbl.get("type", "other"),
                "tile_row": tile.row,
                "tile_col": tile.col,
                "tile_scale": tile.scale,
            })

        logger.info(
            "[OCRAgent] Tile r%d c%d (%s): %d text items extracted",
            tile.row, tile.col, tile.scale, len(labels)
        )
        return labels

    def extract_room_labels(self, tile: Tile) -> list[str]:
        """Convenience: return only room label strings."""
        all_labels = self.extract_text(tile)
        return [
            lbl["text"]
            for lbl in all_labels
            if lbl["type"] == "room_label"
        ]

    def clean_label(self, text: str) -> str:
        """Normalise a raw OCR label to a clean area name."""
        # Remove common noise
        text = re.sub(r"\s+", " ", text).strip()
        # Title-case but preserve acronyms
        words = text.split()
        cleaned = []
        for w in words:
            if w.isupper() and len(w) <= 4:  # keep acronyms: AHU, HC, IT
                cleaned.append(w)
            else:
                cleaned.append(w.title())
        return " ".join(cleaned)