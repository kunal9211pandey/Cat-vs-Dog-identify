"""
Preprocessor
============
Image enhancement + rotation correction + multi-scale tiling.

Pipeline
--------
1. Denoise           (fastNlMeans — gentle to preserve thin CAD lines)
2. CLAHE contrast    (adaptive histogram equalisation, L-channel only)
3. Unsharp-mask      (sharpen thin lines)
4. Orientation fix   (detect 90°/180°/270° rotations via aspect-ratio heuristic
                      then fine deskew via Hough lines for sub-5° skew)
5. Tile at multiple scales  (each tile stores its origin for coord mapping)

Zoom tool (zoom_region)
-----------------------
Used by agents to inspect a small region at higher resolution.
Handles arbitrary rotations — if the image was corrected, zoom coords are
already in corrected space.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Iterator

import cv2
import numpy as np
from PIL import Image

from config import TILE_CONFIGS

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
#  Data classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class Tile:
    """One tile extracted from the full image."""
    image:     Image.Image
    row:       int
    col:       int
    scale:     str
    origin_px: tuple[int, int]
    size_px:   tuple[int, int]
    full_size: tuple[int, int]

    def tile_to_full_px(self, tx: int, ty: int) -> tuple[int, int]:
        return self.origin_px[0] + tx, self.origin_px[1] + ty

    def tile_bbox_to_full_px(self, tx1, ty1, tx2, ty2):
        ox, oy = self.origin_px
        return ox + tx1, oy + ty1, ox + tx2, oy + ty2

    def tile_bbox_to_norm(self, tx1, ty1, tx2, ty2) -> list[float]:
        W, H = self.full_size
        fx1, fy1, fx2, fy2 = self.tile_bbox_to_full_px(tx1, ty1, tx2, ty2)
        return [
            round(max(0, fx1) / W, 4),
            round(max(0, fy1) / H, 4),
            round(min(W, fx2) / W, 4),
            round(min(H, fy2) / H, 4),
        ]


# ──────────────────────────────────────────────────────────────────────────────
#  Enhancement helpers
# ──────────────────────────────────────────────────────────────────────────────

def _to_cv(img: Image.Image) -> np.ndarray:
    return cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)


def _to_pil(arr: np.ndarray) -> Image.Image:
    return Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2RGB))


def enhance_image(img: Image.Image) -> Image.Image:
    """
    Denoise → CLAHE → unsharp mask.
    Designed to improve readability of thin CAD lines without blurring text.
    """
    arr = _to_cv(img)

    # 1. Gentle denoising (h=5 → low, keeps thin lines intact)
    arr = cv2.fastNlMeansDenoisingColored(
        arr, None, h=5, hColor=5,
        templateWindowSize=7, searchWindowSize=21,
    )

    # 2. CLAHE on L channel only (preserves colour balance)
    lab  = cv2.cvtColor(arr, cv2.COLOR_BGR2LAB)
    L, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    L     = clahe.apply(L)
    arr   = cv2.cvtColor(cv2.merge([L, a, b]), cv2.COLOR_LAB2BGR)

    # 3. Unsharp mask (sharpen thin CAD lines)
    blurred = cv2.GaussianBlur(arr, (0, 0), 2.0)
    arr     = cv2.addWeighted(arr, 1.5, blurred, -0.5, 0)

    return _to_pil(arr)


# ──────────────────────────────────────────────────────────────────────────────
#  Rotation / orientation correction
# ──────────────────────────────────────────────────────────────────────────────

def _coarse_orient_correction(img: Image.Image) -> tuple[Image.Image, int]:
    """
    Detect and correct 90°/180°/270° mis-orientations.

    Strategy: most architectural floor plans are wider than they are tall
    (landscape).  If the image is taller than wide, rotate 90° clockwise.
    Returns (corrected_image, rotation_angle_applied_degrees).
    """
    W, H = img.size
    angle = 0
    if H > W * 1.15:          # clearly portrait → rotate 90° CW
        img   = img.rotate(-90, expand=True)
        angle = 90
        logger.info("Coarse orientation: rotated 90° CW (was portrait)")
    return img, angle


def detect_skew_angle(img: Image.Image, max_angle: float = 5.0) -> float:
    """
    Detect sub-5° skew using Hough lines on a downsampled greyscale version.
    Returns angle in degrees (positive = clockwise).
    """
    # Work on a small thumbnail for speed
    THUMB_W = 800
    scale   = THUMB_W / img.width
    thumb   = img.convert("L").resize(
        (THUMB_W, int(img.height * scale)), Image.LANCZOS
    )
    arr  = np.array(thumb)
    _, th = cv2.threshold(arr, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    edges = cv2.Canny(th, 50, 150)

    lines = cv2.HoughLines(edges, 1, math.pi / 180, threshold=100)
    if lines is None:
        return 0.0

    angles = []
    for rho, theta in lines[:, 0]:
        deg = math.degrees(theta) - 90
        if abs(deg) < max_angle:
            angles.append(deg)

    if not angles:
        return 0.0

    median = float(np.median(angles))
    logger.debug("Detected fine skew angle: %.2f°", median)
    return median


def correct_rotation(img: Image.Image) -> tuple[Image.Image, float]:
    """
    Full rotation pipeline:
      1. Coarse: fix 90°/180°/270° flips
      2. Fine: fix up to 5° skew with Hough lines

    Returns (corrected_image, total_angle_applied_degrees).
    """
    img, coarse_angle = _coarse_orient_correction(img)

    fine_angle = detect_skew_angle(img)
    total      = coarse_angle + fine_angle

    if abs(fine_angle) >= 0.1:
        img = img.rotate(-fine_angle, expand=False, fillcolor=(255, 255, 255))
        logger.info("Fine skew corrected by %.2f° (total: %.2f°)", fine_angle, total)
    else:
        logger.info("No fine skew detected (coarse only: %d°)", coarse_angle)

    return img, total


# ──────────────────────────────────────────────────────────────────────────────
#  Multi-scale tiling
# ──────────────────────────────────────────────────────────────────────────────

def generate_tiles(img: Image.Image) -> list[Tile]:
    """
    Produces overlapping tiles at each scale defined in TILE_CONFIGS.
    Each tile remembers its origin so coordinates can be mapped back to
    the full image.
    """
    W, H  = img.size
    tiles = []

    for cfg in TILE_CONFIGS:
        tile_size  = cfg["size"]
        overlap    = cfg["overlap"]
        step       = int(tile_size * (1 - overlap))
        scale_name = cfg["label"]

        col_origins = list(range(0, W, step))
        row_origins = list(range(0, H, step))

        # Ensure the last strip always covers the right / bottom edge
        if not col_origins or col_origins[-1] + tile_size < W:
            col_origins.append(max(0, W - tile_size))
        if not row_origins or row_origins[-1] + tile_size < H:
            row_origins.append(max(0, H - tile_size))

        # Deduplicate origins
        col_origins = sorted(set(col_origins))
        row_origins = sorted(set(row_origins))

        for ri, oy in enumerate(row_origins):
            for ci, ox in enumerate(col_origins):
                x2 = min(ox + tile_size, W)
                y2 = min(oy + tile_size, H)
                x1 = max(0, x2 - tile_size)
                y1 = max(0, y2 - tile_size)

                tile_img = img.crop((x1, y1, x2, y2))

                # Upscale small edge tiles to full tile_size for the vision model
                if tile_img.size != (tile_size, tile_size):
                    tile_img = tile_img.resize((tile_size, tile_size), Image.LANCZOS)

                tiles.append(Tile(
                    image     = tile_img,
                    row       = ri,
                    col       = ci,
                    scale     = scale_name,
                    origin_px = (x1, y1),
                    size_px   = (x2 - x1, y2 - y1),
                    full_size = (W, H),
                ))

    logger.info("Generated %d tiles for image %dx%d", len(tiles), W, H)
    return tiles


# ──────────────────────────────────────────────────────────────────────────────
#  Zoom tool
# ──────────────────────────────────────────────────────────────────────────────

def zoom_region(
    img: Image.Image,
    x1_n: float, y1_n: float, x2_n: float, y2_n: float,
    upscale_to: int = 1024,
) -> Image.Image:
    """
    Crop a normalised (0-1) region from `img` and upscale to `upscale_to` px
    on the longer axis.  Mimics a human zooming in 200%.
    """
    W, H   = img.size
    x1, y1 = int(x1_n * W), int(y1_n * H)
    x2, y2 = int(x2_n * W), int(y2_n * H)

    # Guard: ensure valid crop
    x1, x2 = max(0, min(x1, W-1)), max(x1+1, min(x2, W))
    y1, y2 = max(0, min(y1, H-1)), max(y1+1, min(y2, H))

    crop   = img.crop((x1, y1, x2, y2))
    aspect = crop.width / max(crop.height, 1)
    new_w  = upscale_to if aspect >= 1 else int(upscale_to * aspect)
    new_h  = int(upscale_to / aspect) if aspect >= 1 else upscale_to
    return crop.resize((max(1, new_w), max(1, new_h)), Image.LANCZOS)


# ──────────────────────────────────────────────────────────────────────────────
#  Full preprocessing pipeline
# ──────────────────────────────────────────────────────────────────────────────

class Preprocessor:
    """
    Wraps all preprocessing steps.

    Usage
    -----
    prep   = Preprocessor(pil_image)
    result = prep.run()
    # result["enhanced"]   → PIL.Image  (full-size, enhanced + deskewed)
    # result["tiles"]      → list[Tile]
    # result["skew_angle"] → float (total angle corrected, degrees)
    """

    def __init__(self, image: Image.Image):
        self.original = image

    def run(self) -> dict:
        logger.info("Preprocessing: %dx%d image", *self.original.size)

        # Step 1: Enhance
        enhanced = enhance_image(self.original)
        logger.info("Enhancement done")

        # Step 2: Rotation / orientation correction
        corrected, angle = correct_rotation(enhanced)
        logger.info("Rotation done (total correction: %.2f°)", angle)

        # Step 3: Multi-scale tiling
        tiles = generate_tiles(corrected)

        return {
            "original":   self.original,
            "enhanced":   corrected,
            "skew_angle": angle,
            "tiles":      tiles,
        }
