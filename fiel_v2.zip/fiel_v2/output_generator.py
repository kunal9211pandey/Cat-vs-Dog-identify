"""
Output Generator
================
Produces two deliverables for each processed floor:

1. Annotated PNG image
   • Coloured semi-transparent overlay for each area
   • Area name label centred in the box
   • Small dot at lighting fixture positions

2. Structured JSON file matching the required schema:
   {
     "floor": "...",
     "image_size_px": [W, H],
     "areas": [
       {
         "name": "...",
         "coordinates": [x1, y1, x2, y2],   ← pixel coords
         "area_size_sqm": ...,
         "capacity": { "persons": ..., ... },
         "lighting": { "recommended_fixtures": ..., "positions": [...] }
       }
     ]
   }
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from config import (
    ANNOTATION_COLORS, ANNOTATION_ALPHA,
    BOX_BORDER_WIDTH, LABEL_FONT_SCALE, LABEL_THICKNESS,
    OUTPUT_DIR,
)

logger = logging.getLogger(__name__)

# Try to load a basic font; fall back to PIL default
try:
    _FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    _FONT_LG   = ImageFont.truetype(_FONT_PATH, 18)
    _FONT_SM   = ImageFont.truetype(_FONT_PATH, 12)
except Exception:
    _FONT_LG = _FONT_SM = ImageFont.load_default()


# ──────────────────────────────────────────────────────────────────────────────
#  Colour helper
# ──────────────────────────────────────────────────────────────────────────────

def _get_color(category: str) -> tuple[int, int, int]:
    cat_up = (category or "").upper()
    for k, v in ANNOTATION_COLORS.items():
        if k.upper() in cat_up:
            return v
    return ANNOTATION_COLORS["default"]


# ──────────────────────────────────────────────────────────────────────────────
#  Image annotation
# ──────────────────────────────────────────────────────────────────────────────

def annotate_image(
    base_image: Image.Image,
    areas: list[dict],
    title: str = "",
) -> Image.Image:
    """
    Draw colour overlays + clear labels on the floor plan.
    Improvements over v1:
      • Area number badge (circle with number) in corner of each box
      • White pill background behind text — readable on any surface
      • Larger font — 14px instead of 12px
      • No light-position dots (reduces visual clutter)
    """
    W, H   = base_image.size
    result = base_image.convert("RGBA").copy()
    overlay= Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw_o = ImageDraw.Draw(overlay)

    for idx, area in enumerate(areas, start=1):
        px = area.get("coordinates_px")
        if not px or len(px) < 4:
            n  = area.get("coordinates_norm", [0, 0, 0, 0])
            px = [int(n[0]*W), int(n[1]*H), int(n[2]*W), int(n[3]*H)]

        x1, y1, x2, y2 = px
        if x2 <= x1 or y2 <= y1:
            continue

        color = _get_color(area.get("category", area.get("name", "")))
        alpha = int(ANNOTATION_ALPHA * 255)

        # Semi-transparent fill
        draw_o.rectangle(
            [x1, y1, x2, y2],
            fill    = (*color, alpha),
            outline = (*color, 230),
            width   = max(2, BOX_BORDER_WIDTH),
        )

        # ── Label text with white background pill ─────────────────────────
        name  = area.get("name", "Unknown")
        label = f"{idx}. {name}"
        cx    = (x1 + x2) // 2
        cy    = (y1 + y2) // 2

        # Measure text size
        try:
            bbox = _FONT_LG.getbbox(label)
            tw   = bbox[2] - bbox[0]
            th   = bbox[3] - bbox[1]
        except Exception:
            tw, th = len(label) * 9, 16

        pad  = 5
        rx1, ry1 = cx - tw//2 - pad, cy - th//2 - pad
        rx2, ry2 = cx + tw//2 + pad, cy + th//2 + pad
        # Clamp pill to box
        rx1 = max(x1+2, rx1); ry1 = max(y1+2, ry1)
        rx2 = min(x2-2, rx2); ry2 = min(y2-2, ry2)

        # White pill background
        draw_o.rounded_rectangle([rx1, ry1, rx2, ry2],
                                  radius=4, fill=(255,255,255,210))
        # Dark text
        draw_o.text((cx, cy), label,
                    fill=(30,30,30,255), font=_FONT_LG, anchor="mm")

    # Merge overlay
    result = Image.alpha_composite(result, overlay).convert("RGB")

    # Title bar
    if title:
        draw_t = ImageDraw.Draw(result)
        draw_t.rectangle([0, 0, W, 44], fill=(20, 20, 20))
        draw_t.text((W // 2, 22), title, fill=(255,255,255), font=_FONT_LG, anchor="mm")

    return result


def _wrap_text(text: str, max_chars: int = 20) -> list[str]:
    words  = text.split()
    lines  = []
    line   = ""
    for w in words:
        if len(line) + len(w) + 1 > max_chars and line:
            lines.append(line)
            line = w
        else:
            line = (line + " " + w).strip()
    if line:
        lines.append(line)
    return lines or [text[:max_chars]]


# ──────────────────────────────────────────────────────────────────────────────
#  JSON serialisation
# ──────────────────────────────────────────────────────────────────────────────

def build_json(
    areas:      list[dict],
    floor_name: str,
    image_size: tuple[int, int],
    pdf_path:   str = "",
) -> dict:
    """Build clean output JSON — only essential fields, no giant positions arrays."""
    W, H = image_size
    clean_areas = []

    for i, area in enumerate(areas, start=1):
        px = area.get("coordinates_px")
        if not px:
            n  = area.get("coordinates_norm", [0, 0, 0, 0])
            px = [int(n[0]*W), int(n[1]*H), int(n[2]*W), int(n[3]*H)]

        lt       = area.get("lighting", {})
        capacity = area.get("capacity", {})

        entry = {
            "id":              i,
            "name":            area.get("name", "Unknown"),
            "category":        area.get("category", area.get("name", "Unknown")),
            # Coordinates — pixel [x1,y1,x2,y2] and normalised [0..1]
            "coordinates_px":  px,
            "coordinates_norm": [round(v, 4) for v in area.get("coordinates_norm", [])],
            "area_sqm":        round(area.get("area_size_sqm", 0), 1),
            "confidence":      round(area.get("confidence", 1.0), 2),
            # What the model actually saw inside the room
            "furniture_observed": area.get("furniture_observed", ""),
            # Capacity
            "capacity_persons": capacity.get("persons", 0),
            # Lighting — just the count + target, no position arrays
            "lighting": {
                "fixtures_count":   lt.get("recommended_fixtures", 0),
                "lux_target":       lt.get("target_lux", 200),
                "fixture_type":     "40W LED Panel 600×600mm",
                "emergency_lights": lt.get("emergency_lights", 0),
                "standard":         "IS 3646",
            },
        }

        if area.get("validation_issue"):
            entry["flag"] = area["validation_issue"]

        clean_areas.append(entry)

    return {
        "floor":          floor_name,
        "source":         pdf_path,
        "image_size_px":  list(image_size),
        "total_areas":    len(clean_areas),
        "total_sqm":      round(sum(a["area_sqm"] for a in clean_areas), 1),
        "total_capacity": sum(a["capacity_persons"] for a in clean_areas),
        "areas":          clean_areas,
    }


# ──────────────────────────────────────────────────────────────────────────────
#  Save helpers
# ──────────────────────────────────────────────────────────────────────────────

def save_outputs(
    image:      Image.Image,
    areas:      list[dict],
    floor_name: str,
    pdf_path:   str = "",
    out_dir:    Path = OUTPUT_DIR,
) -> dict[str, Path]:
    """Annotate image and save both PNG and JSON. Returns paths."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    safe_name  = floor_name.replace(" ", "_").replace("/", "-")
    img_path   = out_dir / f"{safe_name}_annotated.jpg"
    json_path  = out_dir / f"{safe_name}_areas.json"

    # 1. Annotated image
    annotated = annotate_image(image, areas, title=floor_name)

    # Downscale for saving (keep aspect ratio, max 4000px wide)
    if annotated.width > 4000:
        scale = 4000 / annotated.width
        annotated = annotated.resize(
            (4000, int(annotated.height * scale)), Image.LANCZOS
        )
    annotated.save(str(img_path), "JPEG", quality=92)
    logger.info("Annotated image saved -> %s", img_path)

    # 2. JSON
    data = build_json(areas, floor_name, image.size, pdf_path)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    logger.info("JSON saved -> %s (%d areas)", json_path, len(areas))

    return {"image": img_path, "json": json_path}