"""
Orchestrator
============
Coordinates all agents in the correct order for each PDF.

Pipeline per floor
------------------
PDF  --> PDFProcessor
          |
          |-- text_areas   (from embedded PDF text, confidence=1.0)
          +-- image        (rendered at PDF_DPI)
               |
               v
         Preprocessor  (enhance + deskew + tiles)
               |
               |-- VisionAgent  (coarse tiles -> detect unlabeled areas)
               |-- ZoomRotate   (NEW: uncovered regions -> zoom+rotate -> identify)
               +-- InferenceAgent (still-unlabeled -> RAG + LLM decision)
               |
               v
         SpatialAgent   (NMS + gap detection + sqm)
               |
               v
         PlanningAgent  (capacity)
               |
               v
         ElectricalAgent (lighting)
               |
               v
         ValidationAgent (sanity + LLM coherence)
               |
               v
         OutputGenerator (annotated image + JSON)

RAG behaviour
-------------
  - Built ONCE from built-in descriptions; saved to disk.
  - Each new floor's labeled areas are learned and saved immediately.
  - Already-learned floors are skipped on subsequent runs.
  - Unseen floors benefit from all previously-accumulated knowledge.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path

from config import OUTPUT_DIR, LEGEND_X_FRAC, TITLE_Y_FRAC
from pdf_processor  import PDFProcessor
from preprocessor   import Preprocessor
from rag_system     import RAGSystem
from output_generator import save_outputs

from agents.vision_agent     import VisionAgent
from agents.ocr_agent        import OCRAgent
from agents.inference_agent  import InferenceAgent
from agents.validation_agent import ValidationAgent
from agents.spatial_agent    import SpatialAgent
from agents.planning_agent   import PlanningAgent
from agents.electrical_agent import ElectricalAgent

logger = logging.getLogger(__name__)

# Minimum confidence threshold to keep a zoom-rotate detection
_ZOOM_CONF_THRESHOLD = 0.55
# How many uncovered regions to zoom-scan (top N largest)
_MAX_ZOOM_REGIONS    = 8


class Orchestrator:
    """
    Main controller.

    Parameters
    ----------
    use_vision : bool
        If True, run VisionAgent on image tiles (uses Groq API credits).
    max_vision_tiles : int
        Limit on how many coarse tiles to send to VisionAgent.
    """

    def __init__(
        self,
        use_vision:       bool = True,
        max_vision_tiles: int  = 6,
    ):
        self.use_vision       = use_vision
        self.max_vision_tiles = max_vision_tiles

        # ── RAG: load from disk OR build once ──────────────────────────────
        logger.info("Initialising RAG system...")
        self.rag = RAGSystem()
        if not self.rag.load():
            logger.info("RAG not found on disk -- building from descriptions (first run only)")
            self.rag.build_from_descriptions()
            self.rag.save()
        logger.info("RAG ready.")

        # ── Agents (share same RAG) ─────────────────────────────────────────
        self.vision_agent    = VisionAgent(self.rag)
        self.ocr_agent       = OCRAgent(self.rag)
        self.inference_agent = InferenceAgent(self.rag)
        self.validation_agent= ValidationAgent(self.rag)
        self.planning_agent  = PlanningAgent(self.rag)
        self.electrical_agent= ElectricalAgent(self.rag)

    # ── public ────────────────────────────────────────────────────────────────

    def run_single(self, pdf_path: str | Path) -> dict:
        """Process one PDF end-to-end."""
        pdf_path   = Path(pdf_path)
        floor_name = self._guess_floor_name(pdf_path)
        logger.info("=" * 60)
        logger.info("Processing: %s  ->  %s", pdf_path.name, floor_name)

        t0 = time.time()

        # ── Step 1: PDF extraction ────────────────────────────────────────
        proc       = PDFProcessor(pdf_path)
        pdf_result = proc.process()
        image      = pdf_result["image"]
        text_areas = pdf_result["text_areas"]
        for a in text_areas:
            a["source_pdf"] = floor_name
        logger.info("Step 1 done: %d text areas extracted", len(text_areas))

        # ── Step 0 (after image load): Detect building type ───────────────
        if self.use_vision:
            build_info = self.vision_agent.detect_building_and_image_type(image)
            building_type    = self.vision_agent.building_type
            image_type       = self.vision_agent.image_type
            areas_glimpsed   = self.vision_agent.building_areas_glimpsed
            logger.info(
                "Step 0 done: building_type=%s | image_type=%s | %d areas glimpsed",
                building_type, image_type, len(areas_glimpsed),
            )
        else:
            building_type  = "corporate_office"
            image_type     = "unknown"
            areas_glimpsed = []
            logger.info("Step 0: Skipped (no-vision mode)")

        # Pass building context to inference agent
        self.inference_agent.building_type = building_type
        self.inference_agent.image_type    = image_type

        # ── RAG: learn from this floor (only once per floor) ──────────────
        if not self.rag.is_floor_known(floor_name):
            added = self.rag.add_labeled_areas(text_areas, floor_name=floor_name)
            if added:
                logger.info("RAG: learned + saved knowledge for '%s'", floor_name)
        else:
            logger.info("RAG: '%s' already in knowledge base -- skip", floor_name)

        # ── Step 2: Preprocessing ─────────────────────────────────────────
        prep   = Preprocessor(image)
        prep_r = prep.run()
        tiles      = prep_r["tiles"]
        enh_img    = prep_r["enhanced"]
        W, H       = enh_img.size
        logger.info("Step 2 done: %d tiles generated (%dx%d px)", len(tiles), W, H)

        # ── Step 3: Vision agent on coarse tiles ──────────────────────────
        vision_areas: list[dict] = []
        if self.use_vision:
            coarse  = [t for t in tiles if t.scale == "coarse"]
            sampled = self._sample_tiles(coarse, self.max_vision_tiles)
            logger.info("Step 3: VisionAgent on %d coarse tiles...", len(sampled))
            for tile in sampled:
                try:
                    detected = self.vision_agent.analyze_tile(tile)
                    vision_areas.extend(detected)
                except Exception as exc:
                    logger.warning("VisionAgent tile error: %s", exc)
            logger.info("Step 3 done: %d areas from tile vision", len(vision_areas))
        else:
            logger.info("Step 3: Vision skipped (use_vision=False)")

        # ── Step 4: Merge all area sources ────────────────────────────────
        all_areas = text_areas + vision_areas
        logger.info("Step 4: Combined areas: %d", len(all_areas))

        # ── Step 5: Inference for unlabeled areas ─────────────────────────
        unlabeled = [a for a in all_areas if not a.get("has_label")]
        if unlabeled:
            logger.info(
                "Step 5: InferenceAgent on %d unlabeled areas...", len(unlabeled)
            )
            inferred      = self.inference_agent.batch_infer(unlabeled, floor_name)
            labeled_only  = [a for a in all_areas if a.get("has_label")]
            all_areas     = labeled_only + inferred
        logger.info("Step 5 done: %d areas total", len(all_areas))

        # ── Step 6: Spatial (NMS + gap detection) ─────────────────────────
        spatial_agent = SpatialAgent(image_size_px=(W, H), rag_system=self.rag)
        all_areas     = spatial_agent.process(all_areas)
        logger.info("Step 6 done: %d areas after NMS+gap detection", len(all_areas))

        # ── Step 7: Zoom + Rotate scan for Unidentified / low-conf areas ──
        if self.use_vision:
            all_areas = self._zoom_rotate_pass(all_areas, enh_img, W, H)
            logger.info(
                "Step 7 done: %d areas after zoom+rotate pass", len(all_areas)
            )
        else:
            logger.info("Step 7: Zoom+rotate skipped (use_vision=False)")

        # ── Step 8: Planning (capacity) ───────────────────────────────────
        all_areas = self.planning_agent.batch_estimate(all_areas)
        logger.info("Step 8 done: capacity estimated")

        # ── Step 9: Electrical (lighting) ─────────────────────────────────
        all_areas = self.electrical_agent.batch_recommend(all_areas)
        logger.info("Step 9 done: lighting recommended")

        # ── Step 10: Validation ───────────────────────────────────────────
        all_areas = self.validation_agent.validate(all_areas, floor_name)
        logger.info("Step 10 done: validation complete")

        # ── Step 11: Save outputs ─────────────────────────────────────────
        paths = save_outputs(
            image      = enh_img,
            areas      = all_areas,
            floor_name = floor_name,
            pdf_path   = str(pdf_path),
            out_dir    = OUTPUT_DIR,
        )

        elapsed = time.time() - t0
        summary = {
            "floor":        floor_name,
            "pdf":          str(pdf_path),
            "total_areas":  len(all_areas),
            "elapsed_sec":  round(elapsed, 1),
            "output_image": str(paths["image"]),
            "output_json":  str(paths["json"]),
        }

        logger.info(
            "[OK] %s done in %.1fs -- %d areas | Image: %s | JSON: %s",
            floor_name, elapsed,
            len(all_areas), paths["image"], paths["json"],
        )
        return summary

    def run_folder(self, pdf_folder: str | Path) -> list[dict]:
        """Process all PDFs in a folder."""
        folder  = Path(pdf_folder)
        pdfs    = sorted(folder.glob("*.pdf"))
        logger.info("Found %d PDFs in %s", len(pdfs), folder)
        results = []
        for pdf in pdfs:
            try:
                results.append(self.run_single(pdf))
            except Exception as exc:
                logger.error("Failed to process %s: %s", pdf.name, exc, exc_info=True)
        return results

    # ── private ───────────────────────────────────────────────────────────────

    def _zoom_rotate_pass(
        self,
        all_areas: list[dict],
        enh_img,
        W: int,
        H: int,
    ) -> list[dict]:
        """
        For every area currently labelled "Unidentified Area" or with
        confidence < 0.6, attempt a zoom+rotate scan to find the real name.

        Replaces low-confidence placeholder areas with properly identified ones.
        """
        # Identify candidates for zoom scan
        candidates = [
            a for a in all_areas
            if (a.get("name", "").lower() in ("unidentified area", "unknown", "")
                or float(a.get("confidence", 1.0)) < 0.60)
            and a.get("source") != "pdf_text"  # never re-process PDF text areas
        ]

        if not candidates:
            logger.info("Step 7: No low-confidence areas to zoom-scan")
            return all_areas

        # Sort by area size descending (scan largest unknown regions first)
        def _area_size(a):
            n = a.get("coordinates_norm", [0, 0, 0, 0])
            return (n[2] - n[0]) * (n[3] - n[1])

        candidates.sort(key=_area_size, reverse=True)
        to_scan = candidates[:_MAX_ZOOM_REGIONS]

        logger.info(
            "Step 7: Zoom+rotate scan for %d low-confidence regions...",
            len(to_scan),
        )

        # Build set of indices to replace
        replace_map: dict[int, list[dict]] = {}

        for idx, area in enumerate(all_areas):
            if area not in to_scan:
                continue

            n = area.get("coordinates_norm", [0, 0, 0, 0])
            if n[2] - n[0] < 0.005 or n[3] - n[1] < 0.005:
                continue  # skip degenerate boxes

            # Expand region slightly for context
            x1 = max(0.0, n[0] - 0.01);  y1 = max(0.0, n[1] - 0.01)
            x2 = min(1.0, n[2] + 0.01);  y2 = min(1.0, n[3] + 0.01)

            logger.info(
                "  Zoom+rotate: %s (conf=%.2f) at norm(%.2f,%.2f->%.2f,%.2f)",
                area.get("name", "?"), area.get("confidence", 0),
                x1, y1, x2, y2,
            )

            found = self.vision_agent.analyze_region_with_zoom_rotate(
                enh_img, x1, y1, x2, y2
            )

            if found:
                # Inherit spatial metadata from original area
                for f in found:
                    f["source"] = "vision_zoom_rotate"
                    if "area_size_sqm" in area:
                        f.setdefault("area_size_sqm", area["area_size_sqm"])
                replace_map[idx] = found
                logger.info(
                    "  -> Identified %d area(s) via zoom+rotate: %s",
                    len(found), [f["name"] for f in found],
                )

        if not replace_map:
            return all_areas

        # Rebuild area list: replace low-conf areas with zoom detections
        updated = []
        for idx, area in enumerate(all_areas):
            if idx in replace_map:
                updated.extend(replace_map[idx])
            else:
                updated.append(area)

        # Re-run NMS to clean up any new overlaps introduced
        spatial_agent = SpatialAgent(image_size_px=(W, H), rag_system=self.rag)
        updated = [spatial_agent._add_pixel_coords(a) for a in updated]
        updated = spatial_agent._non_max_suppression(updated)
        updated = [spatial_agent._estimate_area_size(a) for a in updated]
        updated.sort(key=lambda a: (
            a.get("coordinates_norm", [0,0,0,0])[1],
            a.get("coordinates_norm", [0,0,0,0])[0],
        ))
        return updated

    @staticmethod
    def _guess_floor_name(pdf_path: Path) -> str:
        name = pdf_path.stem.upper()
        # Check longer keys first so "L14" matches before "L1"
        mapping = {
            "L24": "24th Floor",  "L23": "23rd Floor",  "L22": "22nd Floor",
            "L21": "21st Floor",  "L20": "20th Floor",  "L19": "19th Floor",
            "L18": "18th Floor",  "L17": "17th Floor",  "L16": "16th Floor",
            "L15": "15th Floor",  "L14": "14th Floor",  "L13": "13th Floor",
            "L12": "12th Floor",  "L11": "11th Floor",  "L10": "10th Floor",
            "L9":  "9th Floor",   "L8":  "8th Floor",   "L7":  "7th Floor",
            "L6":  "6th Floor",   "L5":  "5th Floor",   "L4":  "4th Floor",
            "L3":  "3rd Floor",   "L2":  "2nd Floor",   "L1":  "1st Floor",
            "B1":  "Basement 01", "B2":  "Basement 02", "B3":  "Basement 03",
            "GF":  "Ground Floor","LG":  "Lower Ground","TF":  "Terrace Floor",
            "FF":  "First Floor", "SF":  "Second Floor","TH":  "Third Floor",
            "POD": "Podium Floor","RF":  "Roof Floor",
        }
        for k, v in mapping.items():
            if k in name:
                return v
        return pdf_path.stem.replace("_", " ").title()

    @staticmethod
    def _sample_tiles(tiles, n: int):
        """Pick n tiles spread evenly across the image."""
        if len(tiles) <= n:
            return tiles
        step = max(1, len(tiles) // n)
        return tiles[::step][:n]