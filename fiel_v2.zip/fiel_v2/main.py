#!/usr/bin/env python3
"""
CAD AI Pipeline — Main Entry Point
====================================
Usage:
  python main.py --input ./data/pdfs          # process entire folder
  python main.py --input L17.pdf              # process single PDF
  python main.py --input ./data/pdfs --no-vision  # text-only mode (fast)

Output (in ./data/output/):
  <FloorName>_annotated.jpg  <- colour-coded floor plan image
  <FloorName>_areas.json     <- full structured JSON
"""

import argparse
import io
import json
import logging
import sys
from pathlib import Path


# ── UTF-8 logging setup (fixes Windows cp1252 UnicodeEncodeError) ─────────────
def _make_utf8_stream_handler():
    """
    On Windows the default stdout uses cp1252 which cannot encode arrows/ticks.
    Wrap with UTF-8 explicitly so Unicode characters log correctly everywhere.
    """
    try:
        # Python >= 3.7: reconfigure stdout encoding in-place
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        return logging.StreamHandler(sys.stdout)
    except AttributeError:
        # Fallback for older Python: wrap the buffer
        utf8_stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )
        return logging.StreamHandler(utf8_stdout)


logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt = "%H:%M:%S",
    handlers= [
        _make_utf8_stream_handler(),
        logging.FileHandler("pipeline.log", mode="w", encoding="utf-8"),
    ],
)
logger = logging.getLogger("main")


def parse_args():
    p = argparse.ArgumentParser(description="CAD Floor Plan AI Pipeline")
    p.add_argument("--input",      required=True,
                   help="Path to PDF file or folder containing PDFs")
    p.add_argument("--no-vision",  action="store_true",
                   help="Skip Groq vision calls (faster, uses PDF text only)")
    p.add_argument("--max-tiles",  type=int, default=6,
                   help="Max tiles per floor sent to VisionAgent (default: 6)")
    p.add_argument("--output-dir", default=None,
                   help="Override output directory")
    return p.parse_args()


def _image_to_tmp_pdf(img_path: Path) -> Path:
    """
    Convert a JPG/PNG/TIF image to a single-page PDF so the normal
    pipeline can process it without any code changes to orchestrator.
    Temporary PDF is saved next to the image with a .pdf extension.
    """
    from PIL import Image as PILImage
    import fitz  # pymupdf

    img = PILImage.open(img_path).convert("RGB")
    tmp_pdf = img_path.with_suffix(".pdf")

    # Save image as PDF via pymupdf (lossless, preserves resolution)
    doc  = fitz.open()
    rect = fitz.Rect(0, 0, img.width, img.height)
    page = doc.new_page(width=img.width, height=img.height)
    import io, base64
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=95)
    page.insert_image(rect, stream=buf.getvalue())
    doc.save(str(tmp_pdf))
    doc.close()

    logger.info("Image converted to temporary PDF: %s", tmp_pdf)
    return tmp_pdf


def main():
    args       = parse_args()
    input_path = Path(args.input)
    use_vision = not args.no_vision

    if args.output_dir:
        import config
        config.OUTPUT_DIR = Path(args.output_dir)
        config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 70)
    logger.info("  CAD AI Pipeline  |  Input: %s  |  Vision: %s",
                input_path, "ON" if use_vision else "OFF (text-only)")
    logger.info("=" * 70)

    from orchestrator import Orchestrator
    orch = Orchestrator(
        use_vision       = use_vision,
        max_vision_tiles = args.max_tiles,
    )

    IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}

    if input_path.is_file() and input_path.suffix.lower() == ".pdf":
        results = [orch.run_single(input_path)]
    elif input_path.is_file() and input_path.suffix.lower() in IMAGE_EXTS:
        logger.info("Image input detected — converting to PDF first...")
        tmp_pdf = _image_to_tmp_pdf(input_path)
        results = [orch.run_single(tmp_pdf)]
    elif input_path.is_dir():
        results = orch.run_folder(input_path)
    else:
        logger.error("Input must be a .pdf file or a folder. Got: %s", input_path)
        sys.exit(1)

    # ── Summary ───────────────────────────────────────────────────────────────
    logger.info("")
    logger.info("=" * 70)
    logger.info("  PIPELINE COMPLETE  --  %d floor(s) processed", len(results))
    logger.info("=" * 70)
    for r in results:
        logger.info(
            "  %-20s  %3d areas  %6.1fs  ->  %s",
            r["floor"], r["total_areas"], r["elapsed_sec"], r["output_json"]
        )
    logger.info("")

    return results


if __name__ == "__main__":
    main()